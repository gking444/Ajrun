#!/usr/bin/env python3
"""ARJUN Pipeline — Main entry point with real-time interruption.

Implements the strict STT → LLM → Action → TTS pipeline with barge-in:

    User Speech
          │
          ▼
    Speech-to-Text (STT)  ←── background listener runs continuously
          │
          ▼
    Large Language Model (LLM)  ←── cancellable on barge-in
          │
          ▼
    Action Dispatcher
          │
          ▼
    Action Execution
          │
          ▼
    Text-to-Speech (TTS)  ←── cancellable on barge-in
          │
          ▼
    Assistant Voice Output

Real-time interruption rules (enforced here):
  1. Always listen for new user input, even while speaking.
  2. If the user speaks while ARJUN is responding:
     - Immediately stop speaking (cancel TTS).
     - Cancel any in-progress LLM generation.
     - Treat the new input as the highest-priority request.
     - Discard any remaining text from the previous response.
  3. Never talk over the user.
  4. If intent is ambiguous, ask a short clarifying question before acting.

Usage:
    python -m arjun_pipeline.main           # voice mode (default)
    python -m arjun_pipeline.main --text    # text mode (type instead of speak)
"""
from __future__ import annotations

import os
import sys
import threading
import time
from typing import Optional

# Ensure the package root is on the path when run as a script
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services import (
    CancellationToken, PipelineConfig, configure_logging, get_logger,
    get_event_bus,
)
from utils import (
    EVENT_STT_COMPLETE, EVENT_LLM_COMPLETE,
    EVENT_ACTION_COMPLETE, EVENT_TTS_COMPLETE,
)
from audio import AudioManager
from llm import Conversation, LLMRouter
from actions import (
    ActionDispatcher, BrowserActions, ApplicationActions,
    SystemActions, FileActions, WebActions, MediaActions, CustomActions,
)
from models import PipelineResult, STTResult, LLMIntent, ActionResult

log = get_logger("main")


class ArjunPipeline:
    """The main ARJUN pipeline — wires all stages together with barge-in."""

    def __init__(self, config: Optional[PipelineConfig] = None):
        self.config = config or PipelineConfig.from_env()
        configure_logging(self.config.logging)
        self.events = get_event_bus()

        # ── Stage 1+6: Audio (STT + TTS) ──
        self.audio = AudioManager(
            self.config.audio, self.config.stt, self.config.tts
        )

        # ── Stage 2+3: LLM ──
        self.conversation = Conversation(self.config.llm, self.config.memory)
        self.router = LLMRouter(self.conversation, self.config.llm)

        # ── Stage 4+5: Actions ──
        self.dispatcher = ActionDispatcher()
        self._register_actions()

        # ── Barge-in state ──
        self._interrupt_event = threading.Event()
        self._current_cancel_token: Optional[CancellationToken] = None
        self._processing_lock = threading.Lock()
        self._should_exit = False
        self._last_user_text: Optional[str] = None

        log.info("ARJUN Pipeline initialized (with barge-in support)")
        log.info(f"  STT:  {'available' if self.audio.stt_available else 'unavailable'}")
        if self.conversation.client.backend:
            log.info(f"  LLM:  {self.conversation.client.backend} ({self.conversation.client.model or 'auto'})")
        else:
            log.info(f"  LLM:  no backend detected (configured: {self.config.llm.backend})")
        log.info(f"  TTS:  {'available' if self.audio.tts_available else 'unavailable'}")

    def _register_actions(self) -> None:
        """Register all action modules with the dispatcher."""
        self.browser = BrowserActions()
        self.apps = ApplicationActions()
        self.system = SystemActions()
        self.files = FileActions()
        self.web = WebActions()
        self.media = MediaActions()
        self.custom = CustomActions(llm_chat=self._llm_chat)

        self.dispatcher.register_module("browser", self.browser)
        self.dispatcher.register_module("app", self.apps)
        self.dispatcher.register_module("system", self.system)
        self.dispatcher.register_module("files", self.files)
        self.dispatcher.register_module("web", self.web)
        self.dispatcher.register_module("media", self.media)
        self.dispatcher.register_module("code", self.custom)

    def _llm_chat(self, prompt: str) -> str:
        """LLM callback for custom actions (code generation, audit, etc.).

        Uses the migrated AIGateway's query() method which returns (ok, response).
        """
        try:
            ok, response = self.conversation.client.query(prompt)
            if ok:
                return response
            log.warning(f"LLM chat callback failed: {response}")
            return ""
        except Exception as exc:
            log.error(f"LLM chat callback failed: {exc}")
            return ""

    # ════════════════════════════════════════════════════════════════
    # BARGE-IN HANDLING
    # ════════════════════════════════════════════════════════════════

    def _on_barge_in(self, text: str) -> None:
        """Called by the background listener when the user speaks during TTS.

        Per spec rules 2, 4, 8:
          - Immediately stop speaking (cancel TTS).
          - Cancel any in-progress LLM generation.
          - Store the new text as the highest-priority request.
          - Discard any unfinished previous response.
        """
        log.info(f"[BARGE-IN] User interrupted with: {text!r}")
        # 1. Cancel TTS
        self.audio.cancel_speech()
        # 2. Cancel in-progress LLM generation
        if self._current_cancel_token:
            self._current_cancel_token.cancel()
        # 3. Store the new text — the main loop will pick it up
        self._last_user_text = text
        self._interrupt_event.set()

    # ════════════════════════════════════════════════════════════════
    # PIPELINE CYCLE
    # ════════════════════════════════════════════════════════════════

    def run_once(self, text_input: Optional[str] = None) -> PipelineResult:
        """Execute one full pipeline cycle.

        If text_input is provided, skip STT (text mode).
        Otherwise, listen for speech (voice mode).

        Returns the full PipelineResult for logging/metrics.
        """
        result = PipelineResult()
        pipeline_start = time.time()

        # ── Stage 1: Speech-to-Text ──
        if text_input is not None:
            # Text mode — apply SpeechNormalizer for word→number conversion
            from utils import SpeechNormalizer
            normalized = SpeechNormalizer.normalize(text_input)
            result.stt = STTResult(text=normalized or text_input)
            log.info(f"[STT] Text input: {text_input!r} → normalized: {result.stt.text!r}")
        else:
            log.info("[STT] Listening...")
            result.stt = self.audio.listen_and_transcribe()
            # Apply SpeechNormalizer to recognized speech too
            if result.stt.success and result.stt.text:
                from utils import SpeechNormalizer
                normalized = SpeechNormalizer.normalize(result.stt.text)
                if normalized:
                    result.stt = STTResult(
                        text=normalized,
                        confidence=result.stt.confidence,
                        language=result.stt.language,
                    )
                    log.info(f"[STT] Normalized: {result.stt.text!r}")
            self.events.emit(EVENT_STT_COMPLETE, text=result.stt.text, success=result.stt.success)

        if not result.stt.success:
            self._speak("I didn't catch that.")
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            return result

        # Check exit words (also check stop words for TTS interruption)
        stt_text = result.stt.text.lower().strip()
        if stt_text in self.config.exit_words:
            self._speak("Goodbye!")
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            self._should_exit = True
            return result
        # If user said a stop word while TTS was speaking, cancel TTS and
        # don't process further (the stop word itself isn't a command)
        if stt_text in self.config.stop_words and self.audio.is_speaking:
            log.info(f"[Stop] User said '{stt_text}' — cancelling TTS")
            self.audio.cancel_speech()
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            return result

        # ── Stage 2+3: LLM Router (with cancellation) ──
        # Create a cancellation token for this LLM call
        cancel_token = CancellationToken()
        self._current_cancel_token = cancel_token

        log.info("[LLM] Routing to LLM...")
        result.llm = self.router.route(result.stt.text, cancel_token=cancel_token)
        self.events.emit(EVENT_LLM_COMPLETE, intent=result.llm.intent,
                         confidence=result.llm.confidence, success=result.llm.success)

        # Clear the cancel token
        self._current_cancel_token = None

        # Check if the LLM call was cancelled by barge-in
        if result.llm.error == "cancelled":
            log.info("[Pipeline] LLM cancelled by barge-in — discarding result")
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            return result

        if not result.llm.success:
            self._speak(result.llm.response or "I'm having trouble understanding the request.")
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            return result

        # ── Clarification check ──
        # Per spec rules 11-15: if the LLM says the request is ambiguous,
        # speak the clarifying question and wait for the next input.
        if result.llm.needs_clarification:
            log.info(f"[Clarify] Asking: {result.llm.response!r}")
            self._speak(result.llm.response)
            # If there are options, speak them too
            if result.llm.clarification_options:
                time.sleep(0.3)
                options_text = ". ".join(result.llm.clarification_options)
                self._speak(options_text)
            result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
            return result

        # ── Stage 4+5: Action Dispatcher ──
        log.info(f"[Dispatcher] Executing intent: {result.llm.intent}")
        result.action = self.dispatcher.execute(result.llm)
        self.events.emit(EVENT_ACTION_COMPLETE, intent=result.llm.intent,
                         success=result.action.success)

        # ── Stage 6: Text-to-Speech ──
        # Speak the action result message (or the LLM's response for conversation)
        spoken_text = result.action.message or result.llm.response
        log.info(f"[TTS] Speaking: {spoken_text!r}")
        result.tts_spoken = self._speak(spoken_text)
        self.events.emit(EVENT_TTS_COMPLETE, text=spoken_text, success=result.tts_spoken)

        result.total_elapsed_ms = int((time.time() - pipeline_start) * 1000)
        log.info(f"[Pipeline] Complete in {result.total_elapsed_ms}ms "
                 f"(intent={result.llm.intent}, action={'OK' if result.action.success else 'FAIL'})")
        return result

    def _speak(self, text: str) -> bool:
        """Speak text via TTS (non-blocking for barge-in support).

        If the user interrupts during speech, the background listener
        will fire _on_barge_in() which cancels the TTS.
        """
        return self.audio.speak(text, blocking=False)

    # ════════════════════════════════════════════════════════════════
    # MAIN LOOP
    # ════════════════════════════════════════════════════════════════

    def run(self, text_mode: bool = False) -> None:
        """Run the main loop with real-time interruption support.

        Voice mode:
          1. Start the background listener (always-on barge-in detector).
          2. Wait for speech → run pipeline cycle.
          3. While TTS is speaking, the background listener is active.
             If the user speaks, _on_barge_in() fires:
               - cancels TTS
               - cancels in-progress LLM
               - sets _last_user_text
          4. After TTS finishes (or is cancelled), check if there's a
             pending barge-in request and process it immediately.

        Text mode:
          - Same pipeline, but STT is replaced with input().
          - Barge-in doesn't apply (typed input is inherently synchronous).
        """
        self._should_exit = False

        # Calibrate microphone once at startup
        if not text_mode and self.audio.mic_available:
            self.audio.calibrate()

        print("\n" + "=" * 60)
        print("  ARJUN Pipeline — STT → LLM → Action → TTS")
        print("  Real-time interruption ENABLED (barge-in)")
        print("=" * 60)
        if text_mode:
            print("  Mode: TEXT (type your commands)")
        else:
            print("  Mode: VOICE (speak — you can interrupt anytime)")
        print(f"  LLM:  {self.config.llm.backend} ({self.config.llm.model})")
        print(f"  Say 'quit' or press Ctrl-C to stop.")
        print("=" * 60 + "\n")

        try:
            if not text_mode:
                # Start the background listener for barge-in detection
                self.audio.start_background_listen(self._on_barge_in)
                log.info("[Main] Background listener started — barge-in active")

            while not self._should_exit:
                try:
                    if text_mode:
                        try:
                            user_input = input("💬  You: ").strip()
                        except EOFError:
                            break
                        if not user_input:
                            continue
                        self.run_once(text_input=user_input)
                    else:
                        # Voice mode: wait for either a barge-in or a fresh phrase
                        if self._interrupt_event.is_set():
                            # Process the barge-in text
                            self._interrupt_event.clear()
                            barge_text = self._last_user_text
                            self._last_user_text = None
                            if barge_text:
                                log.info(f"[Main] Processing barge-in: {barge_text!r}")
                                self.run_once(text_input=barge_text)
                        else:
                            # Normal listening cycle
                            print("🎤  Listening...")
                            self.run_once()
                            # Brief cool-down to avoid capturing TTS tail
                            time.sleep(0.3)

                        # After the cycle, if TTS is still going (long response),
                        # wait for it to finish OR for a barge-in
                        while self.audio.is_speaking and not self._interrupt_event.is_set():
                            time.sleep(0.05)

                except KeyboardInterrupt:
                    print("\n  Interrupted.")
                    break
                except Exception as exc:
                    log.error(f"Pipeline cycle error: {exc}", exc_info=True)
                    self._speak("Something went wrong. Please try again.")
        finally:
            if not text_mode:
                self.audio.stop_background_listen()
                self.audio.cancel_speech()
            print("\n  👋  ARJUN stopped.")


def main():
    """Entry point."""
    text_mode = "--text" in sys.argv or "--no-voice" in sys.argv
    config = PipelineConfig.from_env()
    pipeline = ArjunPipeline(config)
    pipeline.run(text_mode=text_mode)


if __name__ == "__main__":
    main()
