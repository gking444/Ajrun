"""Application actions — migrated from ARJUN_COMBINED_FIXED.py.

Open, close, kill applications. Uses a static app database + dynamic
registry/Start Menu scanning on Windows.

Migrated from AppController in the working Python file. Preserves:
  - Static app database with common apps
  - Dynamic registry scanning (Windows)
  - Cross-platform launch via start/open/subprocess
  - Process termination via psutil
"""
from __future__ import annotations

import glob
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from models import ActionResult
from services.logger import get_logger
from utils.helpers import is_windows, is_macos, is_linux

log = get_logger("actions.applications")

try:
    import psutil
    PSUTIL_OK = True
except ImportError:
    PSUTIL_OK = False


# Static app database — mirrors APP_DATABASE from the working Python file.
# Each entry: {display, paths, process, cmd, aliases}
_APP_DATABASE: Dict[str, Dict] = {
    "chrome": {
        "display": "Google Chrome",
        "paths": [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
        ],
        "process": ["chrome.exe"],
        "cmd": "chrome",
        "aliases": ["google chrome", "chromium"],
    },
    "edge": {
        "display": "Microsoft Edge",
        "paths": ["C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"],
        "process": ["msedge.exe"],
        "cmd": "msedge",
        "aliases": ["microsoft edge"],
    },
    "brave": {
        "display": "Brave Browser",
        "paths": [
            "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
            "C:\\Program Files (x86)\\BraveSoftware\\Brave-Browser\\Application\\brave.exe",
        ],
        "process": ["brave.exe"],
        "cmd": "brave",
        "aliases": [],
    },
    "firefox": {
        "display": "Mozilla Firefox",
        "paths": ["C:\\Program Files\\Mozilla Firefox\\firefox.exe"],
        "process": ["firefox.exe"],
        "cmd": "firefox",
        "aliases": ["mozilla firefox"],
    },
    "vscode": {
        "display": "Visual Studio Code",
        "paths": [
            "C:\\Program Files\\Microsoft VS Code\\Code.exe",
            "C:\\Program Files (x86)\\Microsoft VS Code\\Code.exe",
        ],
        "process": ["Code.exe"],
        "cmd": "code",
        "aliases": ["visual studio code", "code"],
    },
    "notepad": {
        "display": "Notepad",
        "paths": ["C:\\Windows\\System32\\notepad.exe"],
        "process": ["notepad.exe"],
        "cmd": "notepad",
        "aliases": [],
    },
    "spotify": {
        "display": "Spotify",
        "paths": [
            "C:\\Users\\*\\AppData\\Roaming\\Spotify\\Spotify.exe",
        ],
        "process": ["Spotify.exe"],
        "cmd": "spotify",
        "aliases": [],
    },
    "terminal": {
        "display": "Terminal",
        "paths": [],
        "process": [],
        "cmd": "cmd" if is_windows() else ("Terminal" if is_macos() else "gnome-terminal"),
        "aliases": ["command prompt", "cmd", "powershell"],
    },
    "explorer": {
        "display": "File Explorer",
        "paths": ["C:\\Windows\\explorer.exe"],
        "process": ["explorer.exe"],
        "cmd": "explorer",
        "aliases": ["file explorer", "windows explorer"],
    },
    "calculator": {
        "display": "Calculator",
        "paths": [],
        "process": [],
        "cmd": "calc" if is_windows() else ("Calculator" if is_macos() else "gnome-calculator"),
        "aliases": ["calc"],
    },
}


class ApplicationActions:
    """Launch and manage applications.

    Migrated from AppController in ARJUN_COMBINED_FIXED.py.
    """

    def __init__(self):
        self._cache: Dict[str, Dict] = {}
        self._scan_static()

    def _scan_static(self) -> None:
        """Scan the static app database and mark which are installed."""
        for key, entry in _APP_DATABASE.items():
            record = {**entry, "installed": False, "resolved_path": None}
            for raw in entry.get("paths", []):
                if "*" in raw:
                    matches = glob.glob(raw)
                    if matches:
                        record["installed"] = True
                        record["resolved_path"] = matches[0]
                        break
                elif os.path.exists(raw):
                    record["installed"] = True
                    record["resolved_path"] = raw
                    break
            if not record["installed"] and entry.get("cmd"):
                if shutil.which(entry["cmd"]):
                    record["installed"] = True
            self._cache[key] = record

    def find_app(self, name: str) -> Optional[Dict]:
        """Find an app by name or alias."""
        name = name.lower().strip()
        # Direct key match
        if name in self._cache:
            return self._cache[name]
        # Alias match
        for key, record in self._cache.items():
            if name in record.get("aliases", []):
                return record
            if name in record.get("display", "").lower():
                return record
        return None

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        """Route app.* intents to their handlers."""
        handlers = {
            "app.open": self._open,
            "app.close": self._close,
            "app.kill": self._kill,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown app action: {intent}")
        return handler(params)

    def _open(self, params: Dict[str, Any]) -> ActionResult:
        """Open an application."""
        name = params.get("name", "").lower()
        if not name:
            return ActionResult(success=False, error="No application name",
                                message="What application should I open?")

        app = self.find_app(name)
        if not app:
            # Try generic launch
            try:
                if is_windows():
                    subprocess.Popen(f"start {name}", shell=True)
                elif is_macos():
                    subprocess.Popen(["open", "-a", name.title()])
                else:
                    subprocess.Popen([name])
                time.sleep(1.0)
                return ActionResult(success=True, message=f"Opening {name}.")
            except Exception as exc:
                return ActionResult(success=False, error=str(exc),
                                    message=f"Could not open {name}: {exc}")

        if not app.get("installed"):
            return ActionResult(success=False, error=f"{app['display']} is not installed",
                                message=f"{app['display']} is not installed.")

        try:
            if app.get("resolved_path"):
                subprocess.Popen([app["resolved_path"]])
            elif app.get("cmd"):
                if is_windows():
                    subprocess.Popen(f"start {app['cmd']}", shell=True)
                else:
                    subprocess.Popen([app["cmd"]])
            time.sleep(1.0)
            return ActionResult(success=True, message=f"Opening {app['display']}.")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc),
                                message=f"Could not open {app['display']}: {exc}")

    def _close(self, params: Dict[str, Any]) -> ActionResult:
        """Close an application gracefully (terminate)."""
        name = params.get("name", "").lower()
        if not name:
            return ActionResult(success=False, error="No application name")
        if not PSUTIL_OK:
            return ActionResult(success=False, error="psutil not available")
        app = self.find_app(name)
        process_names = app.get("process", []) if app else [name]
        try:
            killed = 0
            for proc in psutil.process_iter(["name"]):
                try:
                    pname = (proc.info.get("name") or "").lower()
                    for pName in process_names:
                        if pName.lower() in pname:
                            proc.terminate()
                            killed += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if killed > 0:
                display = app["display"] if app else name
                return ActionResult(success=True, message=f"Closed {killed} {display} process(es).")
            return ActionResult(success=False, error=f"{name} is not running")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _kill(self, params: Dict[str, Any]) -> ActionResult:
        """Force-kill an application."""
        name = params.get("name", "").lower()
        if not name:
            return ActionResult(success=False, error="No process name")
        if not PSUTIL_OK:
            return ActionResult(success=False, error="psutil not available")
        app = self.find_app(name)
        process_names = app.get("process", []) if app else [name]
        try:
            killed = 0
            for proc in psutil.process_iter(["name"]):
                try:
                    pname = (proc.info.get("name") or "").lower()
                    for pName in process_names:
                        if pName.lower() in pname:
                            proc.kill()
                            killed += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if killed > 0:
                display = app["display"] if app else name
                return ActionResult(success=True, message=f"Killed {killed} {display} process(es).")
            return ActionResult(success=False, error=f"{name} is not running")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))
