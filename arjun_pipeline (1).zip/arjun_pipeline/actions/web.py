"""Web actions — search, weather, news, summarize."""
from __future__ import annotations

import subprocess
from typing import Any, Dict

from models import ActionResult
from services.logger import get_logger

log = get_logger("actions.web")

try:
    import requests
    REQ_OK = True
except ImportError:
    REQ_OK = False


class WebActions:
    """Web-related actions (search, weather, news)."""

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        handlers = {
            "web.search": self._search,
            "web.weather": self._weather,
            "web.summarize": self._summarize,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown web action: {intent}")
        return handler(params)

    def _search(self, params: Dict[str, Any]) -> ActionResult:
        import webbrowser
        query = params.get("query", "")
        if not query:
            return ActionResult(success=False, error="No search query")
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        webbrowser.open(url)
        return ActionResult(success=True, message=f"Searching the web for {query}.")

    def _weather(self, params: Dict[str, Any]) -> ActionResult:
        city = params.get("city", "")
        if not city:
            return ActionResult(success=False, error="No city specified")
        if not REQ_OK:
            return ActionResult(success=False, error="requests not installed")
        try:
            # Use wttr.in (free, no API key needed)
            resp = requests.get(f"https://wttr.in/{city}?format=3", timeout=10)
            if resp.status_code == 200:
                weather = resp.text.strip()
                return ActionResult(success=True, message=f"Weather: {weather}",
                                    data={"raw": weather})
            return ActionResult(success=False, error=f"Weather service returned {resp.status_code}")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _summarize(self, params: Dict[str, Any]) -> ActionResult:
        url = params.get("url", "")
        if not url:
            return ActionResult(success=False, error="No URL to summarize")
        # Summarization requires the LLM — this is a placeholder that
        # opens the URL. The LLM can be called separately to summarize.
        import webbrowser
        webbrowser.open(url)
        return ActionResult(success=True, message=f"Opening {url} for reading. Summarization requires the LLM.")
