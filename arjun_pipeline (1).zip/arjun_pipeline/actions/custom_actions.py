"""Custom actions — code generation, analysis, user workflows.

Uses the LLM (passed in as a callback) for code-related tasks.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from models import ActionResult
from services.logger import get_logger

log = get_logger("actions.custom")


class CustomActions:
    """Code generation, analysis, and user-defined workflows."""

    def __init__(self, llm_chat: Optional[Callable[[str], str]] = None):
        """Args:
            llm_chat: A callable that takes a prompt and returns the LLM's text response.
        """
        self._llm_chat = llm_chat

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        handlers = {
            "code.generate": self._generate,
            "code.debug": self._debug,
            "code.review": self._review,
            "code.audit": self._audit,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown custom action: {intent}")
        return handler(params)

    def _generate(self, params: Dict[str, Any]) -> ActionResult:
        if not self._llm_chat:
            return ActionResult(success=False, error="LLM not available for code generation")
        kind = params.get("kind", "code")
        spec = params.get("spec", "the user's request")
        prompt = (f"You are a senior software engineer. Generate {kind} for: {spec}. "
                  f"Output clean, production-quality code in a fenced code block.")
        response = self._llm_chat(prompt)
        return ActionResult(success=True, message="Code generated.",
                            data={"code": response, "full_response": response})

    def _debug(self, params: Dict[str, Any]) -> ActionResult:
        if not self._llm_chat:
            return ActionResult(success=False, error="LLM not available")
        target = params.get("target", "the issue")
        prompt = (f"You are a debugging expert. Help debug: {target}. "
                  f"Identify the root cause and suggest a fix.")
        response = self._llm_chat(prompt)
        return ActionResult(success=True, message="Debug analysis complete.",
                            data={"analysis": response})

    def _review(self, params: Dict[str, Any]) -> ActionResult:
        if not self._llm_chat:
            return ActionResult(success=False, error="LLM not available")
        target = params.get("target", "")
        prompt = (f"You are a code reviewer. Review this code for quality, security, "
                  f"and correctness:\n\n{target}\n\nRate quality 1-10 and suggest improvements.")
        response = self._llm_chat(prompt)
        return ActionResult(success=True, message="Code review complete.",
                            data={"review": response})

    def _audit(self, params: Dict[str, Any]) -> ActionResult:
        if not self._llm_chat:
            return ActionResult(success=False, error="LLM not available")
        target = params.get("target", "")
        prompt = (
            "You are the Supreme Code Surgeon. Perform a 7-persona audit:\n"
            "1. Syntax 2. Logic 3. Flow 4. Security 5. Performance 6. Architecture 7. Testing\n\n"
            f"Code:\n{target}\n\n"
            "Output findings as a JSON array of {severity, issue, fixed_code}."
        )
        response = self._llm_chat(prompt)
        return ActionResult(success=True, message="Full audit complete.",
                            data={"audit": response})
