"""File actions — organize, search, duplicates, move, copy, compress."""
from __future__ import annotations

import hashlib
import shutil
import zipfile
from pathlib import Path
from typing import Any, Dict, List

from models import ActionResult
from services.logger import get_logger
from utils.helpers import categorize_file, resolve_folder

log = get_logger("actions.files")


class FileActions:
    """File organization and management."""

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        handlers = {
            "files.organize": self._organize,
            "files.search": self._search,
            "files.duplicates": self._duplicates,
            "files.move": self._move,
            "files.copy": self._copy,
            "files.compress": self._compress,
            "files.extract": self._extract,
            "files.large_files": self._large_files,
            "files.empty_trash": self._empty_trash,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown files action: {intent}")
        return handler(params)

    def _organize(self, params: Dict[str, Any]) -> ActionResult:
        folder = resolve_folder(params.get("folder", "downloads"))
        if not folder.is_dir():
            return ActionResult(success=False, error=f"Not a folder: {folder}")
        files = [f for f in folder.iterdir() if f.is_file() and not f.name.startswith(".")]
        if not files:
            return ActionResult(success=True, message=f"{folder.name} is already organized.")
        moved = 0
        errors = []
        for f in files:
            cat = categorize_file(f.name)
            target_dir = folder / cat
            target_dir.mkdir(exist_ok=True)
            dst = target_dir / f.name
            if dst.exists():
                base, ext = dst.stem, dst.suffix
                i = 1
                while dst.exists():
                    dst = target_dir / f"{base} ({i}){ext}"
                    i += 1
            try:
                shutil.move(str(f), str(dst))
                moved += 1
            except Exception as exc:
                errors.append(str(exc))
        return ActionResult(
            success=len(errors) == 0,
            message=f"Moved {moved}/{len(files)} files.",
            data={"moved": moved, "errors": errors},
        )

    def _search(self, params: Dict[str, Any]) -> ActionResult:
        query = params.get("query", "").lower()
        folder = resolve_folder(params.get("folder"))
        if not query:
            return ActionResult(success=False, error="No search query")
        results = []
        for entry in folder.rglob("*"):
            if entry.is_file() and query in entry.name.lower():
                results.append({"name": entry.name, "path": str(entry)})
                if len(results) >= 50:
                    break
        if not results:
            return ActionResult(success=True, message="No files matched.")
        return ActionResult(success=True, message=f"Found {len(results)} files.",
                            data={"files": results})

    def _duplicates(self, params: Dict[str, Any]) -> ActionResult:
        folder = resolve_folder(params.get("folder", "downloads"))
        if not folder.is_dir():
            return ActionResult(success=False, error=f"Not a folder: {folder}")
        # Group by size, then hash candidates
        size_groups: dict = {}
        for entry in folder.rglob("*"):
            if entry.is_file() and not entry.name.startswith("."):
                try:
                    size_groups.setdefault(entry.stat().st_size, []).append(entry)
                except OSError:
                    pass
        hash_groups: dict = {}
        for size, items in size_groups.items():
            if len(items) < 2:
                continue
            for item in items:
                try:
                    h = hashlib.sha256()
                    with open(item, "rb") as f:
                        for chunk in iter(lambda: f.read(65536), b""):
                            h.update(chunk)
                    hash_groups.setdefault(h.hexdigest(), []).append(
                        {"path": str(item), "name": item.name, "size": size})
                except Exception:
                    pass
        dups = {k: v for k, v in hash_groups.items() if len(v) >= 2}
        if not dups:
            return ActionResult(success=True, message="No duplicates found.")
        wasted = sum((len(v) - 1) * v[0]["size"] for v in dups.values())
        return ActionResult(
            success=True,
            message=f"Found {len(dups)} duplicate groups ({wasted // (1024*1024)} MB wasted).",
            data={"groups": list(dups.values()), "wasted_bytes": wasted},
        )

    def _move(self, params: Dict[str, Any]) -> ActionResult:
        return self._copy_or_move(params, move=True)

    def _copy(self, params: Dict[str, Any]) -> ActionResult:
        return self._copy_or_move(params, move=False)

    def _copy_or_move(self, params: Dict[str, Any], move: bool) -> ActionResult:
        src = params.get("src")
        dst = params.get("dst")
        if not src or not dst:
            return ActionResult(success=False, error="Need src and dst")
        src_path = Path(src).expanduser().resolve()
        dst_path = Path(dst).expanduser().resolve()
        if not src_path.exists():
            return ActionResult(success=False, error=f"Source not found: {src_path}")
        if dst_path.is_dir():
            dst_path = dst_path / src_path.name
        try:
            if move:
                shutil.move(str(src_path), str(dst_path))
            else:
                shutil.copy2(str(src_path), str(dst_path))
            return ActionResult(success=True, message=f"{'Moved' if move else 'Copied'} {src_path.name}.")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _compress(self, params: Dict[str, Any]) -> ActionResult:
        target = params.get("target")
        if not target:
            return ActionResult(success=False, error="No target")
        target_path = Path(target).expanduser().resolve()
        if not target_path.exists():
            return ActionResult(success=False, error=f"Not found: {target_path}")
        zip_path = target_path.with_suffix(".zip") if target_path.is_file() else target_path.parent / f"{target_path.name}.zip"
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                if target_path.is_file():
                    zf.write(target_path, target_path.name)
                else:
                    for entry in target_path.rglob("*"):
                        if entry.is_file():
                            zf.write(entry, entry.relative_to(target_path))
            return ActionResult(success=True, message=f"Created {zip_path.name}.")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _extract(self, params: Dict[str, Any]) -> ActionResult:
        target = params.get("target")
        if not target:
            return ActionResult(success=False, error="No target")
        target_path = Path(target).expanduser().resolve()
        if not target_path.is_file() or target_path.suffix.lower() != ".zip":
            return ActionResult(success=False, error="Only .zip supported")
        extract_dir = target_path.parent / target_path.stem
        try:
            with zipfile.ZipFile(target_path, "r") as zf:
                zf.extractall(extract_dir)
            return ActionResult(success=True, message=f"Extracted to {extract_dir.name}.")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _large_files(self, params: Dict[str, Any]) -> ActionResult:
        folder = resolve_folder(params.get("folder"))
        min_mb = int(params.get("min_mb", 100))
        results = []
        for entry in folder.rglob("*"):
            if entry.is_file():
                try:
                    size = entry.stat().st_size
                    if size >= min_mb * 1024 * 1024:
                        results.append({"name": entry.name, "path": str(entry), "size": size})
                except OSError:
                    pass
                if len(results) >= 50:
                    break
        results.sort(key=lambda r: r["size"], reverse=True)
        if not results:
            return ActionResult(success=True, message=f"No files larger than {min_mb} MB.")
        return ActionResult(success=True, message=f"Found {len(results)} large files.",
                            data={"files": results})

    def _empty_trash(self, params: Dict[str, Any]) -> ActionResult:
        import sys
        try:
            if sys.platform == "win32":
                subprocess.Popen(["powershell", "-Command", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"], shell=True)
            elif sys.platform == "darwin":
                trash = Path.home() / ".Trash"
                for item in trash.iterdir():
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
            else:
                trash = Path.home() / ".local" / "share" / "Trash" / "files"
                if trash.exists():
                    for item in trash.iterdir():
                        if item.is_dir():
                            shutil.rmtree(item)
                        else:
                            item.unlink()
            return ActionResult(success=True, message="Recycle bin emptied.")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))
