"""Action Dispatcher — receives structured LLM output and routes to action modules.

The dispatcher is the ONLY component that maps intent names to functions.
It validates parameters, executes actions, catches exceptions, and returns
structured ActionResult objects. No business logic lives here — only routing.

Supported action namespaces:
  - browser.*     → actions.browser
  - app.*         → actions.applications
  - system.*      → actions.system
  - files.*       → actions.files
  - web.*         → actions.web
  - media.*       → actions.media
  - code.*        → actions.custom_actions
  - conversation  → no action (TTS speaks the LLM's response directly)
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional

from models import ActionResult, LLMIntent
from services.logger import get_logger
from utils import INTENT_CONVERSATION

log = get_logger("actions.dispatcher")


class ActionDispatcher:
    """Routes intents to registered action handlers.

    Action handlers are registered via `register(namespace, module)`.
    Each module must expose a `handle(intent, parameters) -> ActionResult` method.
    """

    def __init__(self):
        self._handlers: Dict[str, Any] = {}  # namespace → module
        self._action_map: Dict[str, Callable] = {}  # intent → callable

    def register_module(self, namespace: str, module: Any) -> None:
        """Register an action module for a namespace (e.g. "browser", "system")."""
        self._handlers[namespace] = module
        log.info(f"Registered action module: {namespace}")

    def register_action(self, intent: str, handler: Callable[[Dict[str, Any]], ActionResult]) -> None:
        """Register a single intent handler directly."""
        self._action_map[intent] = handler
        log.debug(f"Registered action: {intent}")

    def execute(self, intent_data: LLMIntent) -> ActionResult:
        """Execute the action specified by the LLMIntent.

        This is the Action stage of the pipeline:
            LLMIntent → validate → dispatch → execute → ActionResult

        Args:
            intent_data: The structured LLM output.

        Returns:
            ActionResult with success/failure, message, and data.
        """
        # Conversation intents don't need an action — the TTS will speak
        # the LLM's response directly.
        if intent_data.is_conversation:
            log.info(f"[Dispatcher] Conversation intent — no action needed")
            return ActionResult(success=True, message=intent_data.response)

        intent = intent_data.intent
        params = intent_data.parameters or {}

        # Confidence check
        if intent_data.confidence < 0.6:
            log.info(f"[Dispatcher] Low confidence ({intent_data.confidence:.2f}) — asking for clarification")
            return ActionResult(
                success=False,
                message=f"I'm not sure I understood. Could you rephrase that? {intent_data.response}",
                error="low_confidence",
            )

        # Find the handler
        handler = self._action_map.get(intent)
        if handler is None:
            # Try namespace-based lookup
            namespace = intent.split(".")[0] if "." in intent else intent
            module = self._handlers.get(namespace)
            if module and hasattr(module, "handle"):
                handler = module.handle

        if handler is None:
            log.warning(f"[Dispatcher] No handler for intent: {intent}")
            return ActionResult(
                success=False,
                message=f"I don't know how to do that yet.",
                error=f"Unknown intent: {intent}",
            )

        # Execute with error containment
        start = time.time()
        try:
            log.info(f"[Dispatcher] Executing: {intent} with params={params}")
            result = handler(intent, params) if hasattr(handler, '__call__') and handler.__code__.co_argcount >= 2 else handler(params)
            if not isinstance(result, ActionResult):
                # Wrap raw dict results
                if isinstance(result, dict):
                    result = ActionResult(
                        success=result.get("success", True),
                        message=result.get("message", ""),
                        data=result.get("data", {}),
                        error=result.get("error"),
                    )
                else:
                    result = ActionResult(success=True, message=str(result))

            result.elapsed_ms = int((time.time() - start) * 1000)
            log.info(f"[Dispatcher] {intent} → {'OK' if result.success else 'FAIL'} ({result.elapsed_ms}ms)")
            return result

        except Exception as exc:
            elapsed = int((time.time() - start) * 1000)
            log.error(f"[Dispatcher] {intent} raised: {exc}", exc_info=True)
            return ActionResult(
                success=False,
                message=f"I couldn't complete that action because {exc}",
                error=str(exc),
                elapsed_ms=elapsed,
            )

    @property
    def available_intents(self) -> list:
        """Return all registered intent names (for the LLM prompt)."""
        return list(self._action_map.keys())
