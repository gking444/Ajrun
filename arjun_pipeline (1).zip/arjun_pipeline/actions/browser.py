"""Browser actions — strict window & tab control.

Per spec: NEVER opens a new browser window if one is already running.
Focuses existing window, reuses current tab, navigates via Ctrl+L.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

from models import ActionResult
from services.logger import get_logger
from utils import INTERNAL_PAGES
from utils.helpers import is_windows, is_macos

log = get_logger("actions.browser")

try:
    import pyautogui
    PAG_OK = True
except ImportError:
    PAG_OK = False

try:
    import psutil
    PSUTIL_OK = True
except ImportError:
    PSUTIL_OK = False


class BrowserActions:
    """Browser automation with strict window control."""

    # Process names by browser
    _PROCESSES = {
        "chrome": ["chrome.exe", "chrome", "chromium"],
        "edge": ["msedge.exe", "msedge"],
        "brave": ["brave.exe", "brave"],
        "firefox": ["firefox.exe", "firefox"],
        "opera": ["opera.exe", "opera"],
        "vivaldi": ["vivaldi.exe", "vivaldi"],
    }

    def __init__(self, tts_callback=None):
        self._tts = tts_callback  # callable(text) for voice prompts

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        """Route browser.* intents to their handlers."""
        handlers = {
            "browser.open": self._open,
            "browser.search": self._search,
            "browser.open_url": self._open_url,
            "browser.new_tab": self._new_tab,
            "browser.close_tab": self._close_tab,
            "browser.new_window": self._new_window,
            "browser.private": self._private,
            "browser.page": self._page,
            "browser.bookmark": self._bookmark,
            "browser.reload": self._reload,
            "browser.back": self._back,
            "browser.forward": self._forward,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown browser action: {intent}")
        return handler(params)

    # ── Helpers ────────────────────────────────────────────────────
    def _is_running(self, browser: str) -> bool:
        """Check if a browser process is running."""
        browser = browser.lower()
        names = self._PROCESSES.get(browser, [browser])
        if not PSUTIL_OK:
            return False
        for proc in psutil.process_iter(["name"]):
            try:
                pname = (proc.info.get("name") or "").lower()
                if any(n.lower() in pname for n in names):
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False

    def _detect_browser(self) -> str:
        """Detect which browser is currently running."""
        for b in ["chrome", "brave", "edge", "firefox", "opera", "vivaldi"]:
            if self._is_running(b):
                return b
        return "chrome"

    def _focus_window(self, browser: str) -> bool:
        """Focus existing browser window + restore if minimized."""
        titles = {
            "chrome": "Chrome", "edge": "Edge", "brave": "Brave",
            "firefox": "Firefox", "opera": "Opera", "vivaldi": "Vivaldi",
        }
        title = titles.get(browser.lower(), browser.title())

        if is_windows():
            try:
                import pygetwindow as gw
                wins = gw.getWindowsWithTitle(title)
                if wins:
                    win = wins[0]
                    if win.isMinimized:
                        win.restore()
                    win.activate()
                    time.sleep(0.3)
                    return True
            except (ImportError, Exception):
                pass
        elif is_macos():
            app_map = {"chrome": "Google Chrome", "edge": "Microsoft Edge",
                       "brave": "Brave Browser", "firefox": "Firefox"}
            app = app_map.get(browser.lower(), browser.title())
            subprocess.Popen(["osascript", "-e", f'tell application "{app}" to activate'],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(0.3)
            return True
        return False

    def _ensure_focused(self, browser: str) -> bool:
        """Focus existing window or launch if not running."""
        browser = browser.lower()
        if self._is_running(browser):
            return self._focus_window(browser) or True  # running, shortcuts may work
        # Launch
        return self._launch(browser)

    def _launch(self, browser: str) -> bool:
        """Launch a browser (only if no instance is running)."""
        try:
            if is_windows():
                cmds = {"chrome": "start chrome", "edge": "start msedge",
                        "brave": "start brave", "firefox": "start firefox"}
                subprocess.Popen(cmds.get(browser, f"start {browser}"), shell=True)
            elif is_macos():
                app_map = {"chrome": "Google Chrome", "edge": "Microsoft Edge",
                           "brave": "Brave Browser", "firefox": "Firefox"}
                subprocess.Popen(["open", "-a", app_map.get(browser, browser.title())])
            else:
                subprocess.Popen([browser])
            time.sleep(2.0)
            return True
        except Exception as exc:
            log.error(f"Launch failed: {exc}")
            return False

    def _navigate_current_tab(self, url: str) -> bool:
        """Navigate the CURRENT tab via Ctrl+L → type URL → Enter."""
        if not PAG_OK:
            return False
        pyautogui.hotkey("ctrl", "l")
        time.sleep(0.2)
        pyautogui.hotkey("ctrl", "a")
        time.sleep(0.05)
        pyautogui.press("delete")
        time.sleep(0.05)
        pyautogui.typewrite(url, interval=0.01)
        time.sleep(0.1)
        pyautogui.press("enter")
        time.sleep(0.3)
        return True

    def _press(self, *keys) -> bool:
        if not PAG_OK:
            return False
        try:
            if len(keys) == 1:
                pyautogui.press(keys[0])
            else:
                pyautogui.hotkey(*keys)
            time.sleep(0.15)
            return True
        except Exception:
            return False

    # ── Action handlers ────────────────────────────────────────────
    def _open(self, params: Dict[str, Any]) -> ActionResult:
        browser = params.get("browser", "chrome").lower()
        if self._ensure_focused(browser):
            return ActionResult(success=True, message=f"Focusing {browser}.")
        return ActionResult(success=False, error=f"Could not open {browser}")

    def _search(self, params: Dict[str, Any]) -> ActionResult:
        query = params.get("query", "")
        if not query:
            return ActionResult(success=False, error="No search query")
        browser = self._detect_browser()
        if not self._ensure_focused(browser):
            return ActionResult(success=False, error="Could not focus browser")
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        if self._navigate_current_tab(url):
            return ActionResult(success=True, message=f"Searching for {query}.")
        return ActionResult(success=False, error="Navigation failed")

    def _open_url(self, params: Dict[str, Any]) -> ActionResult:
        url = params.get("url", "")
        if not url:
            return ActionResult(success=False, error="No URL")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        browser = self._detect_browser()
        if not self._ensure_focused(browser):
            return ActionResult(success=False, error="Could not focus browser")
        if self._navigate_current_tab(url):
            return ActionResult(success=True, message=f"Navigated to {url}.")
        return ActionResult(success=False, error="Navigation failed")

    def _new_tab(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        if self._press("ctrl", "t"):
            return ActionResult(success=True, message="New tab opened.")
        return ActionResult(success=False, error="Could not open new tab")

    def _close_tab(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        if self._press("ctrl", "w"):
            return ActionResult(success=True, message="Tab closed.")
        return ActionResult(success=False, error="Could not close tab")

    def _new_window(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        if self._press("ctrl", "n"):
            return ActionResult(success=True, message="New window opened.")
        return ActionResult(success=False, error="Could not open new window")

    def _private(self, params: Dict[str, Any]) -> ActionResult:
        browser = params.get("browser", self._detect_browser()).lower()
        self._ensure_focused(browser)
        if browser == "firefox":
            self._press("ctrl", "shift", "p")
        else:
            self._press("ctrl", "shift", "n")
        return ActionResult(success=True, message="Private window opened.")

    def _page(self, params: Dict[str, Any]) -> ActionResult:
        page = params.get("page", "").lower()
        browser = self._detect_browser()
        url = INTERNAL_PAGES.get(browser, {}).get(page) or INTERNAL_PAGES.get("chrome", {}).get(page)
        if not url:
            url = f"chrome://{page}"
        if not self._ensure_focused(browser):
            return ActionResult(success=False, error="Could not focus browser")
        if self._navigate_current_tab(url):
            return ActionResult(success=True, message=f"Opened {page}.")
        return ActionResult(success=False, error="Navigation failed")

    def _bookmark(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        self._press("ctrl", "d")
        time.sleep(0.5)
        self._press("enter")
        return ActionResult(success=True, message="Page bookmarked.")

    def _reload(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        self._press("ctrl", "r")
        return ActionResult(success=True, message="Page reloaded.")

    def _back(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        self._press("alt", "left")
        return ActionResult(success=True, message="Going back.")

    def _forward(self, params: Dict[str, Any]) -> ActionResult:
        browser = self._detect_browser()
        self._ensure_focused(browser)
        self._press("alt", "right")
        return ActionResult(success=True, message="Going forward.")
