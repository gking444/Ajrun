"""System actions — migrated from ARJUN_COMBINED_FIXED.py.

Volume, brightness, power, lock, system info.

Migrated from SystemController in the working Python file. Preserves:
  - Strict volume verification (only say "already at" if exact match)
  - pyautogui volume key presses (each press = ~2%)
  - Brightness via screen_brightness_control with PowerShell fallback
  - Cross-platform shutdown/restart/sleep/lock
  - System info: CPU, RAM, disk, battery, uptime, IP
"""
from __future__ import annotations

import ctypes
import shutil
import socket
import subprocess
import sys
import time
from typing import Any, Dict, Optional, Tuple

from models import ActionResult
from services.logger import get_logger
from utils.helpers import is_linux, is_macos, is_windows
from utils.validators import clamp

log = get_logger("actions.system")

try:
    import pyautogui
    PAG_OK = True
except ImportError:
    PAG_OK = False

try:
    import psutil
    PSUTIL_OK = True
except ImportError:
    PSUTIL_OK = False

try:
    import screen_brightness_control as sbc
    SBC_OK = True
except ImportError:
    SBC_OK = False

# Windows process creation flag (no console window)
_NO_WIN_FLAG = 0x08000000 if is_windows() else 0


class SystemActions:
    """System control: volume, brightness, power, lock.

    Migrated from SystemController in ARJUN_COMBINED_FIXED.py.
    """

    def __init__(self):
        self._volume = 0.2  # 20% default
        self._sys_vol = 0   # track system volume internally

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        """Route system.* intents to their handlers."""
        handlers = {
            "system.volume": self._set_volume,
            "system.volume_up": self._volume_up,
            "system.volume_down": self._volume_down,
            "system.mute": self._mute,
            "system.unmute": self._unmute,
            "system.brightness": self._set_brightness,
            "system.brightness_up": self._brightness_up,
            "system.brightness_down": self._brightness_down,
            "system.shutdown": self._shutdown,
            "system.restart": self._restart,
            "system.sleep": self._sleep,
            "system.lock": self._lock,
            "system.info": self._system_info,
            "system.battery": self._battery,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown system action: {intent}")
        return handler(params)

    # ════════════════════════════════════════════════════════════════
    # VOLUME (migrated from SystemController.set_volume)
    # ════════════════════════════════════════════════════════════════

    def _get_volume(self) -> int:
        """Get current volume (0-100) — uses cached value."""
        return int(self._sys_vol)

    def _set_volume(self, params: Dict[str, Any]) -> ActionResult:
        """Set volume to the requested level.

        Per spec: never claim "already at X%" unless current volume has been
        explicitly queried and EXACTLY matches the requested value.
        Always perform the set operation, then confirm with
        "Volume has been set to X%."
        """
        level = params.get("level")
        if level is None:
            return ActionResult(success=False, error="No volume level",
                                message="What volume level?")
        try:
            target_pct = float(level)
        except (TypeError, ValueError):
            return ActionResult(success=False, error="Invalid volume value")

        target_pct = max(0, min(100, target_pct))
        current_pct = self._get_volume()

        # Strict verification: only say "already at" if exact match
        if current_pct is not None and int(current_pct) == int(target_pct):
            return ActionResult(success=True, message=f"Volume already at {int(target_pct)}%.")

        diff = int(target_pct - (current_pct or 0))

        if PAG_OK:
            # Each volume key press changes by ~2% on Windows
            steps = abs(diff) // 2
            if steps == 0:
                steps = 1
            key = "volumeup" if diff > 0 else "volumedown"
            for _ in range(steps):
                pyautogui.press(key)
                time.sleep(0.05)
            self._sys_vol = target_pct
            self._volume = target_pct / 100
            return ActionResult(success=True, message=f"Volume has been set to {int(target_pct)}%.")
        else:
            # Fallback to internal tracking only
            self._sys_vol = target_pct
            self._volume = target_pct / 100
            return ActionResult(
                success=True,
                message=f"Volume has been set to {int(target_pct)}% (simulated — install pyautogui for system control)"
            )

    def _volume_up(self, params: Dict[str, Any]) -> ActionResult:
        step = int(params.get("step", 10))
        cur = self._get_volume()
        return self._set_volume({"level": min(100, cur + step)})

    def _volume_down(self, params: Dict[str, Any]) -> ActionResult:
        step = int(params.get("step", 10))
        cur = self._get_volume()
        return self._set_volume({"level": max(0, cur - step)})

    def _mute(self, params: Dict[str, Any]) -> ActionResult:
        if PAG_OK:
            pyautogui.press("volumemute")
            return ActionResult(success=True, message="Muted")
        if is_linux():
            try:
                subprocess.run(
                    ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1"],
                    timeout=5, capture_output=True
                )
                return ActionResult(success=True, message="Muted")
            except Exception:
                pass
        return ActionResult(success=False, error="Mute not available")

    def _unmute(self, params: Dict[str, Any]) -> ActionResult:
        if PAG_OK:
            pyautogui.press("volumemute")
            return ActionResult(success=True, message="Unmuted")
        if is_linux():
            try:
                subprocess.run(
                    ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"],
                    timeout=5, capture_output=True
                )
                return ActionResult(success=True, message="Unmuted")
            except Exception:
                pass
        return ActionResult(success=False, error="Unmute not available")

    # ════════════════════════════════════════════════════════════════
    # BRIGHTNESS (migrated from SystemController.set_brightness)
    # ════════════════════════════════════════════════════════════════

    def _get_brightness(self) -> Optional[int]:
        if SBC_OK:
            try:
                val = sbc.get_brightness()
                return int(val[0]) if isinstance(val, list) else int(val)
            except Exception as exc:
                log.debug(f"get_brightness: {exc}")
        return None

    def _set_brightness(self, params: Dict[str, Any]) -> ActionResult:
        level = params.get("level")
        if level is None:
            return ActionResult(success=False, error="No brightness level",
                                message="What brightness level?")
        level = max(0, min(100, int(level)))
        if SBC_OK:
            try:
                sbc.set_brightness(level)
                return ActionResult(success=True, message=f"Brightness set to {level}%")
            except Exception as exc:
                log.warning(f"sbc set_brightness: {exc}")
        if is_windows():
            try:
                ps = (
                    f"$m=(Get-WmiObject -Namespace root\\wmi WmiMonitorBrightnessMethods);"
                    f"$m.WmiSetBrightness(1,{level})"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command", ps],
                    timeout=5, creationflags=_NO_WIN_FLAG, capture_output=True
                )
                return ActionResult(success=True, message=f"Brightness set to {level}%")
            except Exception as exc:
                log.warning(f"WMI brightness: {exc}")
        elif is_macos():
            try:
                subprocess.run(
                    ["brightness", str(level / 100)], timeout=5, capture_output=True
                )
                return ActionResult(success=True, message=f"Brightness set to {level}%")
            except Exception:
                pass
        return ActionResult(success=False, error="Brightness control not supported on this display")

    def _brightness_up(self, params: Dict[str, Any]) -> ActionResult:
        pct = int(params.get("step", 10))
        cur = self._get_brightness() or 50
        return self._set_brightness({"level": min(100, cur + pct)})

    def _brightness_down(self, params: Dict[str, Any]) -> ActionResult:
        pct = int(params.get("step", 10))
        cur = self._get_brightness() or 50
        return self._set_brightness({"level": max(0, cur - pct)})

    # ════════════════════════════════════════════════════════════════
    # SYSTEM INFO (migrated from SystemController.get_cpu/get_memory/etc.)
    # ════════════════════════════════════════════════════════════════

    def _system_info(self, params: Dict[str, Any]) -> ActionResult:
        """Return comprehensive system info."""
        if not PSUTIL_OK:
            return ActionResult(success=False, error="psutil not installed")
        lines = []
        # CPU
        pct = psutil.cpu_percent(interval=0.5)
        cores = psutil.cpu_count()
        freq = psutil.cpu_freq()
        f_str = f" @ {freq.current:.0f}MHz" if freq else ""
        lines.append(f"CPU: {pct:.1f}% ({cores} cores{f_str})")
        # Memory
        m = psutil.virtual_memory()
        used = m.used / 1e9
        tot = m.total / 1e9
        lines.append(f"RAM: {used:.1f}/{tot:.1f}GB ({m.percent}%)")
        # Disk
        try:
            u = psutil.disk_usage("/")
            lines.append(f"Disk: {u.free/1e9:.1f}GB free / {u.total/1e9:.0f}GB ({u.percent}%)")
        except Exception:
            pass
        # Battery
        bat = psutil.sensors_battery()
        if bat:
            plugged = "plugged in" if bat.power_plugged else "on battery"
            lines.append(f"Battery: {int(bat.percent)}% ({plugged})")
        return ActionResult(success=True, message=" | ".join(lines), data={"info": lines})

    def _battery(self, params: Dict[str, Any]) -> ActionResult:
        if not PSUTIL_OK:
            return ActionResult(success=False, error="psutil not installed")
        bat = psutil.sensors_battery()
        if not bat:
            return ActionResult(success=False, error="No battery detected")
        pct = int(bat.percent)
        plugged = "plugged in" if bat.power_plugged else "on battery"
        return ActionResult(success=True, message=f"Battery: {pct}% ({plugged})")

    # ════════════════════════════════════════════════════════════════
    # POWER (migrated from SystemController.shutdown/restart/sleep/lock)
    # ════════════════════════════════════════════════════════════════

    def _shutdown(self, params: Dict[str, Any]) -> ActionResult:
        delay = int(params.get("delay", 5))
        try:
            if is_windows():
                subprocess.run(["shutdown", "/s", "/t", str(delay)])
            elif is_macos():
                try:
                    subprocess.run(["osascript", "-e", 'tell app "System Events" to shut down'],
                                   timeout=10)
                except Exception:
                    sudo = shutil.which("sudo")
                    if sudo:
                        subprocess.run([sudo, "shutdown", "-h", "now"])
                    else:
                        return ActionResult(success=False, error="Shutdown: sudo not found")
            else:
                systemctl = shutil.which("systemctl")
                if systemctl:
                    subprocess.run([systemctl, "poweroff"])
                else:
                    sudo = shutil.which("sudo")
                    if sudo:
                        subprocess.run([sudo, "shutdown", "-h", "now"])
                    else:
                        return ActionResult(success=False, error="Shutdown not available")
            return ActionResult(success=True, message=f"Shutting down in {delay}s...")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _restart(self, params: Dict[str, Any]) -> ActionResult:
        delay = int(params.get("delay", 5))
        try:
            if is_windows():
                subprocess.run(["shutdown", "/r", "/t", str(delay)])
            elif is_macos():
                try:
                    subprocess.run(["osascript", "-e", 'tell app "System Events" to restart'],
                                   timeout=10)
                except Exception:
                    sudo = shutil.which("sudo")
                    if sudo:
                        subprocess.run([sudo, "shutdown", "-r", "now"])
                    else:
                        return ActionResult(success=False, error="Restart: sudo not found")
            else:
                systemctl = shutil.which("systemctl")
                if systemctl:
                    subprocess.run([systemctl, "reboot"])
                else:
                    sudo = shutil.which("sudo")
                    if sudo:
                        subprocess.run([sudo, "reboot"])
                    else:
                        return ActionResult(success=False, error="Restart not available")
            return ActionResult(success=True, message=f"Restarting in {delay}s...")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _sleep(self, params: Dict[str, Any]) -> ActionResult:
        try:
            if is_windows():
                subprocess.run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
            elif is_macos():
                subprocess.run(["pmset", "sleepnow"])
            else:
                subprocess.run(["systemctl", "suspend"])
            return ActionResult(success=True, message="Going to sleep")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))

    def _lock(self, params: Dict[str, Any]) -> ActionResult:
        try:
            if is_windows():
                ctypes.windll.user32.LockWorkStation()
            elif is_macos():
                subprocess.run([
                    "/System/Library/CoreServices/Menu Extras/User.menu"
                    "/Contents/Resources/CGSession", "-suspend"
                ])
            else:
                subprocess.run(["loginctl", "lock-session"])
            return ActionResult(success=True, message="Screen locked")
        except Exception as exc:
            return ActionResult(success=False, error=str(exc))
