"""Actions package — dispatcher + 7 action modules."""
from .applications import ApplicationActions
from .browser import BrowserActions
from .custom_actions import CustomActions
from .dispatcher import ActionDispatcher
from .files import FileActions
from .media import MediaActions
from .system import SystemActions
from .web import WebActions

__all__ = [
    "ActionDispatcher", "BrowserActions", "ApplicationActions",
    "SystemActions", "FileActions", "WebActions", "MediaActions", "CustomActions",
]
