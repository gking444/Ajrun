"""Media actions — play, pause, resume, stop."""
from __future__ import annotations

import subprocess
import time
from typing import Any, Dict

from models import ActionResult
from services.logger import get_logger

log = get_logger("actions.media")

try:
    import pyautogui
    PAG_OK = True
except ImportError:
    PAG_OK = False


class MediaActions:
    """Media playback control via keyboard shortcuts."""

    def handle(self, intent: str, params: Dict[str, Any]) -> ActionResult:
        handlers = {
            "media.play": self._play,
            "media.pause": self._pause,
            "media.resume": self._resume,
            "media.stop": self._stop,
        }
        handler = handlers.get(intent)
        if not handler:
            return ActionResult(success=False, error=f"Unknown media action: {intent}")
        return handler(params)

    def _play(self, params: Dict[str, Any]) -> ActionResult:
        query = params.get("query", "")
        if query:
            # Open YouTube search for the query
            import webbrowser
            url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
            webbrowser.open(url)
            return ActionResult(success=True, message=f"Playing {query} on YouTube.")
        # Just press play/pause media key
        if PAG_OK:
            pyautogui.press("playpause")
            return ActionResult(success=True, message="Playing media.")
        return ActionResult(success=False, error="pyautogui unavailable")

    def _pause(self, params: Dict[str, Any]) -> ActionResult:
        if PAG_OK:
            pyautogui.press("playpause")
            return ActionResult(success=True, message="Paused.")
        return ActionResult(success=False, error="pyautogui unavailable")

    def _resume(self, params: Dict[str, Any]) -> ActionResult:
        return self._pause(params)  # same key toggles

    def _stop(self, params: Dict[str, Any]) -> ActionResult:
        if PAG_OK:
            pyautogui.press("stop")
            return ActionResult(success=True, message="Stopped.")
        return ActionResult(success=False, error="pyautogui unavailable")
