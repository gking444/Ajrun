"""ARJUN Pipeline — Clean STT → LLM → Action → TTS voice assistant architecture."""

__version__ = "2.0.0"
__all__ = ["main"]
