# ARJUN Pipeline — STT → LLM → Action → TTS

A clean, modular, production-ready voice assistant where **every interaction follows the same execution pipeline** and **the user can interrupt at any time**.

```
User Speech → STT → LLM → Action Dispatcher → Action Execution → TTS → Voice Output
                                    ↑                                          │
                                    └──────── Barge-in (cancel + restart) ─────┘
```

## Architecture

```
arjun_pipeline/
│
├── main.py                      # Entry point — the strict pipeline loop
│
├── audio/                       # Stage 1 (STT) + Stage 6 (TTS)
│   ├── microphone.py            #   Microphone input + VAD
│   ├── stt.py                   #   Speech-to-Text (Google SR)
│   ├── tts.py                   #   Text-to-Speech (pyttsx3)
│   ├── vad.py                   #   Voice Activity Detection
│   └── audio_manager.py         #   Orchestrates mic + STT + TTS
│
├── llm/                         # Stage 2 + 3 (LLM reasoning)
│   ├── client.py                #   LLM API client (Ollama/OpenAI-compatible)
│   ├── router.py                #   Routes text → LLM → structured JSON
│   ├── prompt.py                #   System prompt + intent schema
│   ├── memory.py                #   Conversation history
│   ├── conversation.py          #   Conversation session manager
│   └── models.py                #   (in __init__.py — dataclasses)
│
├── actions/                     # Stage 4 + 5 (Action dispatch + execution)
│   ├── dispatcher.py            #   Maps intents → handlers, validates params
│   ├── browser.py               #   Browser (strict window control)
│   ├── applications.py          #   App launch/close/kill
│   ├── system.py                #   Volume, brightness, power, lock
│   ├── files.py                 #   Organize, search, dedup, move, compress
│   ├── web.py                   #   Web search, weather, summarize
│   ├── media.py                 #   Play/pause/resume/stop
│   └── custom_actions.py        #   Code generation, audit, workflows
│
├── services/                    # Cross-cutting concerns
│   ├── config.py                #   Central configuration (env vars)
│   ├── logger.py                #   Structured logging
│   ├── events.py                #   Event bus (pub/sub)
│   └── exceptions.py            #   Custom exception hierarchy
│
├── models/                      # Data models (dataclasses)
│   └── __init__.py              #   STTResult, LLMIntent, ActionResult, etc.
│
├── utils/                       # Helpers
│   ├── helpers.py               #   Path resolution, file categorization
│   ├── validators.py            #   URL/volume/path validation
│   └── constants.py             #   Event names, browser processes, file categories
│
└── tests/                       # Test suite
```

## Pipeline Stages

### Stage 1 — Speech-to-Text (STT)
- **Module**: `audio/microphone.py` + `audio/stt.py`
- **Input**: Audio from microphone
- **Output**: `STTResult(text, confidence, language)`
- **Responsibility**: Convert speech to text. No business logic.

### Stage 2 — LLM Routing
- **Module**: `llm/router.py` + `llm/conversation.py`
- **Input**: User text (from STT)
- **Output**: `LLMIntent(intent, parameters, response, confidence)`
- **Responsibility**: Understand intent, extract parameters, generate response. The LLM is the central reasoning engine.

### Stage 3 — Structured LLM Output
The LLM returns strict JSON:
```json
{
  "intent": "browser.search",
  "parameters": {"query": "ChatGPT"},
  "response": "Searching for ChatGPT.",
  "confidence": 0.95
}
```

### Stage 4 — Action Dispatcher
- **Module**: `actions/dispatcher.py`
- **Input**: `LLMIntent`
- **Output**: `ActionResult(success, message, data)`
- **Responsibility**: Map intent names to handlers, validate parameters, execute actions, catch exceptions. No business logic — only routing.

### Stage 5 — Action Execution
- **Modules**: `actions/browser.py`, `actions/system.py`, etc.
- **Input**: Intent + parameters
- **Output**: `ActionResult`
- **Responsibility**: Execute the actual business logic (open browser, set volume, organize files, etc.)

### Stage 6 — Text-to-Speech (TTS)
- **Module**: `audio/tts.py`
- **Input**: Response text (from ActionResult or LLMIntent)
- **Output**: Spoken audio
- **Responsibility**: Synthesize speech and play it. No business logic.

## Main Loop (with real-time interruption)

```python
# Background listener runs continuously — fires on_barge_in() when user speaks
audio.start_background_listen(on_barge_in)

while True:
    # Stage 1: STT
    stt_result = audio.listen_and_transcribe()
    
    # Stage 2+3: LLM (cancellable)
    cancel_token = CancellationToken()
    llm_intent = router.route(stt_result.text, cancel_token=cancel_token)
    
    # If user interrupted during LLM → discard and process new input
    if llm_intent.error == "cancelled":
        continue
    
    # Clarification check — if ambiguous, ask before acting
    if llm_intent.needs_clarification:
        audio.speak(llm_intent.response)
        continue
    
    # Stage 4+5: Action
    action_result = dispatcher.execute(llm_intent)
    
    # Stage 6: TTS (non-blocking, cancellable)
    audio.speak(action_result.message)  # runs in background thread
    while audio.is_speaking:
        if barge_in_pending:
            audio.cancel_speech()  # stop immediately
            break
```

### Barge-in (Real-time Interruption)

The assistant behaves like a human in conversation — the user can interrupt at any moment:

1. **Always listening**: A background listener runs continuously, even while ARJUN is speaking.
2. **Instant cancel**: When the user speaks during TTS, the speech is cancelled immediately (mid-sentence if needed).
3. **Cancel in-progress LLM**: If the LLM is still generating a response when the user interrupts, the generation is abandoned.
4. **Priority to latest input**: The new user input is treated as the highest-priority request. Any unfinished previous response is discarded.
5. **Never talks over the user**: ARJUN stops speaking the moment it detects user speech.

**Implementation**:
- `audio/tts.py`: `cancel()` method stops pyttsx3 mid-utterance; sentences are split so cancellation can happen between them.
- `audio/microphone.py`: `listen_in_background()` runs a daemon thread that continuously captures and recognizes speech.
- `services/cancellation.py`: `CancellationToken` for cooperative cancellation of LLM generation.
- `llm/router.py`: `route(text, cancel_token)` polls the token during LLM call; returns immediately with `error="cancelled"` if barge-in occurs.
- `main.py`: `_on_barge_in()` callback cancels TTS + LLM, stores the new text, and the main loop processes it next.

### Clarification (Ambiguous Requests)

Per spec rules 11-15: if the user's request is unclear, ambiguous, or could have multiple interpretations, ARJUN asks a short clarifying question **before** taking any action.

The LLM is instructed to:
- Set `needs_clarification: true` when the request is ambiguous
- Set `intent: "conversation"` (no action executed)
- Set `response` to a short clarifying question
- Set `clarification_options` to 2-4 likely options

**Examples**:
| User says | ARJUN does |
|---|---|
| "open it" | "What would you like me to open? Chrome, VS Code, or Spotify?" |
| "set the volume" | "To what level? 25%, 50%, or 75%?" |
| "move the file" | "Which file should I move, and where?" |
| "open chrome and search for python" | (intent is clear — executes immediately) |

The clarification question is spoken via TTS, and the user's next utterance is processed normally with the conversation context intact.

## Quick Start

### Voice mode (default)
```bash
python -m arjun_pipeline.main
```

### Text mode (for testing without a microphone)
```bash
python -m arjun_pipeline.main --text
```

### As a library
```python
from services import PipelineConfig
from main import ArjunPipeline

config = PipelineConfig.from_env()
pipeline = ArjunPipeline(config)

# Run one cycle with text input
result = pipeline.run_once(text_input="open chrome and search for python")

# Or run the full voice loop
pipeline.run()
```

## Configuration

All config is in `services/config.py`, loaded from environment variables:

| Env Var | Default | Description |
|---|---|---|
| `ARJUN_STT_ENGINE` | `google` | STT engine |
| `ARJUN_STT_LANGUAGE` | `en-US` | Recognition language |
| `ARJUN_TTS_ENGINE` | `pyttsx3` | TTS engine |
| `ARJUN_TTS_RATE` | `180` | Speech rate (WPM) |
| `ARJUN_LLM_BACKEND` | `ollama` | LLM backend |
| `ARJUN_LLM_BASE_URL` | `http://localhost:11434` | LLM API URL |
| `ARJUN_LLM_MODEL` | `llama3.2` | LLM model name |
| `ARJUN_LLM_API_KEY` | (none) | API key (for OpenAI-compatible) |
| `ARJUN_LLM_CONFIDENCE_THRESHOLD` | `0.6` | Min confidence to execute |
| `ARJUN_MIC_INDEX` | (default) | Microphone device index |
| `ARJUN_WAKE_WORD` | (none) | Wake word (empty = always listening) |
| `ARJUN_LOG_LEVEL` | `INFO` | Logging level |
| `ARJUN_LOG_FILE` | (none) | Log file path |

## Available Intents

### Browser (strict window control)
- `browser.open`, `browser.search`, `browser.open_url`
- `browser.new_tab`, `browser.close_tab`, `browser.new_window`
- `browser.private`, `browser.page`, `browser.bookmark`
- `browser.reload`, `browser.back`, `browser.forward`

### Applications
- `app.open`, `app.close`, `app.kill`

### System
- `system.volume`, `system.volume_up`, `system.volume_down`
- `system.mute`, `system.brightness`
- `system.shutdown`, `system.restart`, `system.sleep`, `system.lock`

### Files
- `files.organize`, `files.search`, `files.duplicates`
- `files.move`, `files.copy`, `files.compress`, `files.extract`
- `files.large_files`, `files.empty_trash`

### Web
- `web.search`, `web.weather`, `web.summarize`

### Media
- `media.play`, `media.pause`, `media.resume`, `media.stop`

### Code
- `code.generate`, `code.debug`, `code.review`, `code.audit`

### Conversation
- `conversation` (no action — TTS speaks the LLM's response directly)

## Error Handling

Every stage has typed exceptions in `services/exceptions.py`:

| Error | Stage | User hears |
|---|---|---|
| `MicrophoneError` | STT | "I didn't catch that." |
| `RecognitionError` | STT | "I didn't catch that." |
| `LLMUnavailableError` | LLM | "I'm having trouble understanding the request." |
| `LLMResponseError` | LLM | "I'm having trouble understanding the request." |
| `UnknownActionError` | Action | "I don't know how to do that yet." |
| `ActionExecutionError` | Action | "I couldn't complete that action because..." |

## Logging

Structured logs at every stage:

```
[Microphone] Listening...
[STT] Recognized: "Open Chrome"
[LLM] Routing: "open chrome"
[LLM] Intent: browser.open (confidence=0.95)
[Dispatcher] Executing: browser.open
[Browser] Focusing existing chrome window
[Dispatcher] browser.open → OK (350ms)
[TTS] Speaking: "Focusing chrome."
[Pipeline] Complete in 412ms (intent=browser.open, action=OK)
```

## Code Quality

- **SOLID**: Each module has a single responsibility
- **DRY**: No duplicated logic across action modules
- **Type hints**: Every function has full type annotations
- **Dataclasses**: `STTResult`, `LLMIntent`, `ActionResult` — typed contracts between stages
- **Dependency injection**: Action modules receive their dependencies via constructor
- **No global mutable state**: Each pipeline instance is self-contained
- **Comprehensive docstrings**: Every class and public method is documented

## Dependencies

```
pip install SpeechRecognition pyttsx3 pyautogui psutil requests
# Optional:
pip install screen_brightness_control  # for brightness control
pip install pygetwindow                # for browser window focus (Windows)
pip install openai anthropic           # for cloud LLM backends
```

For the LLM, install [Ollama](https://ollama.ai) and run:
```bash
ollama pull llama3.2
ollama serve
```
