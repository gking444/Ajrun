"""Text-to-Speech (TTS) module — migrated from ARJUN_COMBINED_FIXED.py.

Thread-safe TTS engine with fresh-engine-per-call pattern, retry logic,
and barge-in cancellation support.

Features (preserved from the working Python file):
  - Fresh pyttsx3 engine per call (avoids state corruption)
  - Retry with a second fresh engine on first-attempt failure
  - Voice preference: Zira, David, Hazel, Samantha, Jenny, Aria
  - _stop_event for immediate interruption (barge-in)
  - speak_streaming() for long AI responses (sentence-by-sentence)
  - set_speed(), set_volume(), mute_tts(), unmute_tts()

Real-time interruption:
  - speak() runs in a daemon thread when blocking=False
  - cancel() sets _stop_event and stops the engine
  - is_speaking property tells the caller if speech is active
"""
from __future__ import annotations

import re
import threading
from typing import Callable, Optional

from services.config import TTSConfig
from services.logger import get_logger

log = get_logger("audio.tts")

try:
    import pyttsx3
    TTS_OK = True
except ImportError:
    TTS_OK = False
    log.info("pyttsx3 not installed — TTS unavailable")


class TTSEngine:
    """Text-to-Speech synthesizer with barge-in cancellation.

    Migrated from TTSCore in ARJUN_COMBINED_FIXED.py.
    """

    # Preferred voices (tried in order)
    _PREFERRED_VOICES = ["zira", "david", "hazel", "samantha", "jenny", "aria"]

    def __init__(self, config: TTSConfig):
        self._config = config
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._speaking = threading.Event()
        self._speak_thread: Optional[threading.Thread] = None
        self._speed = config.voice_rate
        self._volume = config.voice_volume
        self._enabled = True

    @property
    def available(self) -> bool:
        return TTS_OK

    @property
    def is_speaking(self) -> bool:
        """True if speech is currently in progress."""
        return self._speaking.is_set()

    @property
    def enabled(self) -> bool:
        return self._enabled

    # ── Core speak method (migrated from TTSCore.speak) ────────────────

    def speak(self, text: str, blocking: bool = False) -> bool:
        """Speak the given text.

        Args:
            text: The text to synthesize.
            blocking: If True, wait until speech finishes. If False (default),
                      return immediately — speech runs in a daemon thread.

        Returns:
            True if speech was produced, False on error or cancellation.
        """
        if not self.available:
            log.warning(f"[TTS] Unavailable — would say: {text!r}")
            return False
        if not text or not self._enabled:
            return False

        clean = str(text).strip()
        log.info(f"[TTS] Speaking: {clean!r}")

        # Reset the stop flag before speaking
        self._stop_event.clear()

        if blocking:
            return self._do_speak(clean)
        # Non-blocking: run in a daemon thread
        # [M-2] FIX: If non-blocking and lock is already taken, skip to
        # prevent unlimited daemon thread pile-up on rapid commands.
        if self._lock.locked():
            log.debug("[TTS] Skipping non-blocking speak — TTS already in use")
            return False
        self._speak_thread = threading.Thread(
            target=self._do_speak, args=(clean,), daemon=True, name="TTSSpeak"
        )
        self._speak_thread.start()
        return True

    def cancel(self) -> None:
        """Immediately stop any in-progress speech (barge-in).

        Per spec rule 7: cancel the current TTS stream before generating
        or speaking the new response.
        """
        if self._speaking.is_set():
            log.info("[TTS] Cancelling in-progress speech (barge-in)")
        self._stop_event.set()

    # ── Internal speak worker (migrated from TTSCore._do_speak) ────────

    def _do_speak(self, text: str) -> bool:
        """Internal speak worker with retry logic."""
        try:
            with self._lock:
                self._speaking.set()
                try:
                    if not TTS_OK:
                        return False

                    # Check stop flag before starting
                    if self._stop_event.is_set():
                        return False

                    # ── First attempt ──────────────────────────────────
                    engine = self._build_engine()
                    if not engine:
                        return False
                    success = False
                    try:
                        engine.say(text)
                        engine.runAndWait()
                        success = True
                    except Exception as exc:
                        log.warning(f"[TTS] First attempt failed: {exc}")
                    finally:
                        try:
                            engine.stop()
                        except Exception:
                            pass
                        try:
                            del engine
                        except Exception:
                            pass

                    if success or self._stop_event.is_set():
                        return success

                    # ── Retry with fresh engine ────────────────────────
                    log.info("[TTS] Retrying with fresh engine")
                    engine2 = self._build_engine()
                    if engine2 and not self._stop_event.is_set():
                        try:
                            engine2.say(text)
                            engine2.runAndWait()
                            return True
                        except Exception as exc:
                            log.error(f"[TTS] Retry failed: {exc}")
                            return False
                        finally:
                            try:
                                engine2.stop()
                            except Exception:
                                pass
                            try:
                                del engine2
                            except Exception:
                                pass
                    return False
                finally:
                    self._speaking.clear()
        except Exception as exc:
            log.error(f"[TTS] Error: {exc}")
            self._speaking.clear()
            return False

    def _build_engine(self):
        """Build a fresh pyttsx3 engine with preferred voice selection.

        Migrated from TTSCore._build_engine.
        """
        if not TTS_OK:
            return None
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", self._speed)
            engine.setProperty("volume", self._volume)
            voices = engine.getProperty("voices") or []
            for pref in self._PREFERRED_VOICES:
                for v in voices:
                    if v and pref in (v.name or "").lower():
                        engine.setProperty("voice", v.id)
                        break
                else:
                    continue
                break
            return engine
        except Exception as exc:
            log.error(f"[TTS] _build_engine failed: {exc}")
            return None

    # ── Streaming speak for long AI responses (migrated from TTSCore.speak_streaming) ──

    def speak_streaming(self, text: str, stop_check: Optional[Callable[[], bool]] = None) -> None:
        """Speak a long AI response sentence-by-sentence.

        After each sentence the stop_check callback is called; if it returns
        True the speech stops immediately. This lets the main loop keep
        listening for a "stop" command while ARJUN is still talking.

        Args:
            text: Full AI response string.
            stop_check: Optional callable() → bool; returning True aborts.
        """
        if not text or not self._enabled or not self.available:
            return

        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        if not sentences:
            return

        log.info(f"[TTS] Streaming {len(sentences)} sentences")

        def _run():
            self._stop_event.clear()
            for sentence in sentences:
                if self._stop_event.is_set():
                    break
                if stop_check and stop_check():
                    break
                sentence = sentence.strip()
                if not sentence:
                    continue
                with self._lock:
                    if self._stop_event.is_set():
                        break
                    engine = self._build_engine()
                    if not engine:
                        continue
                    try:
                        engine.say(sentence)
                        engine.runAndWait()
                    except Exception:
                        pass
                    finally:
                        try:
                            engine.stop()
                        except Exception:
                            pass
                        try:
                            del engine
                        except Exception:
                            pass

        t = threading.Thread(target=_run, daemon=True, name="TTSStream")
        t.start()

    # ── Configuration methods (migrated from TTSCore) ──────────────────

    def set_speed(self, wpm: int) -> tuple:
        """Set TTS speech rate in words-per-minute."""
        self._speed = max(50, min(400, int(wpm)))
        return True, f"TTS speed set to {self._speed} wpm"

    def set_volume(self, pct: float) -> tuple:
        """Set TTS volume (0-100)."""
        self._volume = max(0.0, min(1.0, float(pct) / 100))
        return True, f"TTS volume set to {int(self._volume*100)}%"

    def mute_tts(self) -> tuple:
        self._enabled = False
        return True, "TTS muted"

    def unmute_tts(self) -> tuple:
        self._enabled = True
        return True, "TTS unmuted"
