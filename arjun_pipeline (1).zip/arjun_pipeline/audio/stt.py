"""Speech-to-Text (STT) module — migrated from ARJUN_COMBINED_FIXED.py.

Converts raw audio to text. Contains NO business logic — it only transcribes.
Uses Google Web Speech API (default) and can be extended for Whisper/Sphinx.

Migrated from VoiceCore.listen() in the working Python file.
"""
from __future__ import annotations

from typing import Optional

from models import STTResult
from services.config import STTConfig
from services.logger import get_logger

log = get_logger("audio.stt")

try:
    import speech_recognition as sr
    SR_OK = True
except ImportError:
    SR_OK = False


class STTEngine:
    """Speech-to-Text transcriber."""

    def __init__(self, config: STTConfig):
        self._config = config
        self._recognizer = sr.Recognizer() if SR_OK else None

    @property
    def available(self) -> bool:
        return SR_OK

    def transcribe(self, audio_data: bytes, sample_rate: int = 16000) -> STTResult:
        """Transcribe raw audio bytes to text.

        Args:
            audio_data: Raw 16-bit PCM audio bytes from the microphone.
            sample_rate: Audio sample rate (default 16000).

        Returns:
            STTResult with the recognized text or an error message.
        """
        if not self.available:
            return STTResult(text="", error="STT engine not installed")

        if not audio_data:
            return STTResult(text="", error="No audio data")

        try:
            # Wrap raw bytes back into AudioData for recognition
            audio = sr.AudioData(audio_data, sample_rate, 2)
            text = self._recognizer.recognize_google(audio, language=self._config.language)
            text = text.strip()
            log.info(f"[STT] Recognized: {text!r}")
            return STTResult(text=text, language=self._config.language)
        except sr.UnknownValueError:
            log.warning("[STT] Could not understand audio")
            return STTResult(text="", error="Could not understand audio")
        except sr.RequestError as exc:
            log.error(f"[STT] Service error: {exc}")
            return STTResult(text="", error=f"STT service error: {exc}")
        except Exception as exc:
            log.error(f"[STT] Unexpected error: {exc}", exc_info=True)
            return STTResult(text="", error=str(exc))
