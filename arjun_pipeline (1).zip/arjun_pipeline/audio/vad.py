"""Voice Activity Detection (VAD).

Detects when speech starts and stops in the audio stream. Used by the
microphone module to know when to stop recording.
"""
from __future__ import annotations

import audioop
from typing import Optional

from services.logger import get_logger

log = get_logger("audio.vad")


class VADDetector:
    """Simple energy-based Voice Activity Detector.

    Uses RMS energy thresholding to detect speech. More sophisticated
    implementations (WebRTC VAD) can be plugged in here.
    """

    def __init__(self, energy_threshold: int = 300, aggressiveness: int = 3):
        self._energy_threshold = energy_threshold
        self._aggressiveness = aggressiveness
        self._dynamic_adjust = True

    def is_speech(self, audio_data: bytes, sample_rate: int = 16000) -> bool:
        """Return True if the audio chunk contains speech."""
        if not audio_data:
            return False
        try:
            rms = audioop.rms(audio_data, 2)  # 16-bit samples
            return rms > self._energy_threshold
        except Exception as exc:
            log.debug(f"VAD error: {exc}")
            return False

    def adjust_threshold(self, audio_data: bytes, factor: float = 1.5) -> None:
        """Dynamically adjust the energy threshold based on ambient noise."""
        if not self._dynamic_adjust or not audio_data:
            return
        try:
            rms = audioop.rms(audio_data, 2)
            if rms > 0:
                self._energy_threshold = int(rms * factor)
        except Exception:
            pass

    @property
    def threshold(self) -> int:
        return self._energy_threshold
