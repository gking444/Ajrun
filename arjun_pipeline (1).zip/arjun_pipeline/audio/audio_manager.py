"""Audio manager — orchestrates microphone + STT + TTS.

This is the single entry point for audio I/O. The main loop calls
`listen_and_transcribe()` to get user speech as text, and `speak()` to
produce voice output. All audio concerns are encapsulated here.

Real-time interruption:
  - speak() runs non-blocking by default so the main loop can keep listening.
  - cancel_speech() immediately stops any in-progress TTS.
  - start_background_listen() / stop_background_listen() control the
    barge-in detector that fires while ARJUN is speaking.
"""
from __future__ import annotations

from typing import Callable, Optional

from models import STTResult
from services.config import AudioConfig, STTConfig, TTSConfig
from services.exceptions import MicrophoneError, STTUnavailableError
from services.logger import get_logger
from .microphone import Microphone
from .stt import STTEngine
from .tts import TTSEngine

log = get_logger("audio.manager")


class AudioManager:
    """Coordinates microphone input, STT, and TTS with barge-in support."""

    def __init__(self, audio_config: AudioConfig, stt_config: STTConfig, tts_config: TTSConfig):
        self._mic = Microphone(audio_config, stt_config)
        self._stt = STTEngine(stt_config)
        self._tts = TTSEngine(tts_config)
        self._calibrated = False

    @property
    def mic_available(self) -> bool:
        return self._mic.available

    @property
    def stt_available(self) -> bool:
        return self._stt.available

    @property
    def tts_available(self) -> bool:
        return self._tts.available

    @property
    def is_speaking(self) -> bool:
        """True if TTS is currently producing speech."""
        return self._tts.is_speaking

    def calibrate(self, duration: float = 1.0) -> None:
        """Calibrate the microphone to ambient noise. Call once at startup."""
        if not self._calibrated:
            self._mic.calibrate(duration)
            self._calibrated = True

    def listen_and_transcribe(self, timeout: float = 8.0, phrase_limit: float = 20.0) -> STTResult:
        """Listen for speech and transcribe it to text.

        This is the STT stage of the pipeline:
            Audio → Microphone → VAD → STT → Text

        Returns:
            STTResult with recognized text or an error.
        """
        if not self.mic_available:
            return STTResult(text="", error="Microphone not available")
        if not self.stt_available:
            return STTResult(text="", error="STT engine not available")

        try:
            audio_data = self._mic.listen(timeout=timeout, phrase_time_limit=phrase_limit)
            if audio_data is None:
                return STTResult(text="", error="No speech detected (timeout)")
            return self._stt.transcribe(audio_data)
        except MicrophoneError as exc:
            return STTResult(text="", error=str(exc))
        except Exception as exc:
            log.error(f"Listen+transcribe error: {exc}", exc_info=True)
            return STTResult(text="", error=str(exc))

    def speak(self, text: str, blocking: bool = False) -> bool:
        """Speak text via TTS. Non-blocking by default for barge-in support.

        Args:
            text: The text to speak.
            blocking: If True, wait until speech finishes. If False (default),
                      return immediately — speech runs in a daemon thread.
                      Use cancel_speech() to interrupt.
        """
        return self._tts.speak(text, blocking=blocking)

    def cancel_speech(self) -> None:
        """Immediately cancel any in-progress TTS speech.

        Per spec rule 7: cancel the current TTS stream before generating
        or speaking the new response.
        """
        self._tts.cancel()

    def start_background_listen(self, callback: Callable[[str], None],
                                phrase_time_limit: float = 15.0) -> None:
        """Start a background listener that calls `callback(text)` on each utterance.

        Per spec rule 1: Always listen for new user input, even while speaking.
        The callback fires whenever speech is recognized — the caller is
        responsible for cancelling TTS and acting on the new input.
        """
        self._mic.listen_in_background(callback, phrase_time_limit=phrase_time_limit)

    def stop_background_listen(self) -> None:
        """Stop the background listener."""
        self._mic.stop_background_listen()

