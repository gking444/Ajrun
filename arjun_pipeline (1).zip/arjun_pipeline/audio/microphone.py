"""Microphone input module — migrated from ARJUN_COMBINED_FIXED.py.

VoiceCore with calibration in a background thread (5-second timeout to
prevent hanging startup if the mic is present but unresponsive).

Features (preserved from the working Python file):
  - Calibration in a background thread with 5s timeout
  - energy_threshold = 300, dynamic_energy_threshold = True
  - dynamic_energy_adjustment_ratio = 1.5
  - pause_threshold = 1.2, phrase_threshold = 0.3
  - non_speaking_duration = 0.8, operation_timeout = 15
  - Background listener for barge-in detection
"""
from __future__ import annotations

import threading
import time
from typing import Callable, Optional

from services.config import AudioConfig, STTConfig
from services.exceptions import MicrophoneError
from services.logger import get_logger
from .vad import VADDetector

log = get_logger("audio.microphone")

try:
    import speech_recognition as sr
    SR_OK = True
except ImportError:
    SR_OK = False
    log.info("speech_recognition not installed — microphone unavailable")


class Microphone:
    """Wraps the speech_recognition Microphone with VAD + background listening.

    Migrated from VoiceCore in ARJUN_COMBINED_FIXED.py.
    """

    def __init__(self, audio_config: AudioConfig, stt_config: STTConfig):
        self._audio_config = audio_config
        self._stt_config = stt_config
        self._vad = VADDetector(
            energy_threshold=stt_config.energy_threshold,
            aggressiveness=audio_config.vad_aggressiveness,
        )
        self._recognizer = None
        self._mic = None
        self.available = False
        self._bg_thread: Optional[threading.Thread] = None
        self._bg_stop = threading.Event()
        self._bg_running = False

        if not SR_OK:
            log.warning("speech_recognition not installed")
            return

        try:
            self._recognizer = sr.Recognizer()
            # Migrated from VoiceCore.__init__ — these tuned values come from
            # the working Python file and produce reliable recognition.
            self._recognizer.energy_threshold = stt_config.energy_threshold or 300
            self._recognizer.dynamic_energy_threshold = stt_config.dynamic_energy
            self._recognizer.dynamic_energy_adjustment_ratio = 1.5
            self._recognizer.pause_threshold = 1.2
            self._recognizer.phrase_threshold = 0.3
            self._recognizer.non_speaking_duration = 0.8
            self._recognizer.operation_timeout = 15
            self._mic = sr.Microphone(
                device_index=audio_config.microphone_index,
                sample_rate=audio_config.sample_rate,
            )

            # [M-4] FIX: Run calibration in a thread with 5s timeout
            calibrated = threading.Event()
            calibration_error = [None]

            def _calibrate():
                try:
                    with self._mic as source:
                        log.info("Calibrating microphone...")
                        self._recognizer.adjust_for_ambient_noise(source, duration=1.0)
                    calibrated.set()
                except Exception as exc:
                    calibration_error[0] = exc
                    calibrated.set()

            cal_thread = threading.Thread(target=_calibrate, daemon=True)
            cal_thread.start()
            completed = calibrated.wait(timeout=5.0)

            if not completed:
                log.warning("VoiceCore: mic calibration timed out after 5s")
                return

            if calibration_error[0]:
                log.warning(f"VoiceCore calibration error: {calibration_error[0]}")
                return

            log.info(f"Microphone initialized (threshold={self._recognizer.energy_threshold})")
            self.available = True

        except Exception as exc:
            log.warning(f"VoiceCore init failed: {exc}")

    @property
    def mic_available(self) -> bool:
        """Alias for backward compat."""
        return self.available

    def calibrate(self, duration: float = 1.0) -> None:
        """Re-calibrate the microphone to ambient noise."""
        if not self.available:
            return
        try:
            with self._mic as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=duration)
            self._vad._energy_threshold = self._recognizer.energy_threshold
            log.info(f"Microphone calibrated (threshold={self._recognizer.energy_threshold})")
        except Exception as exc:
            log.warning(f"Calibration failed: {exc}")

    def listen(self, timeout: float = 8.0, phrase_time_limit: float = 20.0) -> Optional[bytes]:
        """Listen for a single phrase and return raw audio data.

        Args:
            timeout: seconds to wait for speech to start
            phrase_time_limit: max seconds per phrase

        Returns:
            Raw audio bytes, or None if no speech was detected.
        """
        if not self.available:
            raise MicrophoneError("Microphone not available")
        try:
            with self._mic as source:
                audio = self._recognizer.listen(
                    source, timeout=timeout, phrase_time_limit=phrase_time_limit
                )
                return audio.get_raw_data()
        except sr.WaitTimeoutError:
            log.debug("Listen timeout — no speech detected")
            return None
        except Exception as exc:
            log.error(f"Listen error: {exc}")
            raise MicrophoneError(str(exc))

    def listen_in_background(self, callback: Callable[[str], None],
                             phrase_time_limit: float = 15.0) -> None:
        """Start a background listener that calls `callback(text)` on each utterance.

        Per spec rule 1: Always listen for new user input, even while speaking.
        """
        if not self.available:
            log.warning("Cannot start background listen — microphone unavailable")
            return
        if self._bg_running:
            log.debug("Background listener already running")
            return

        self._bg_stop.clear()
        self._bg_running = True

        def _bg_loop():
            log.info("[Mic] Background listener started")
            while not self._bg_stop.is_set():
                try:
                    with self._mic as source:
                        audio = self._recognizer.listen(
                            source, timeout=1.0, phrase_time_limit=phrase_time_limit
                        )
                    if self._bg_stop.is_set():
                        break
                    try:
                        text = self._recognizer.recognize_google(
                            audio, language=self._stt_config.language
                        ).strip().lower()
                        if text:
                            log.info(f"[Mic] Background heard: {text!r}")
                            callback(text)
                    except sr.UnknownValueError:
                        pass
                    except sr.RequestError as exc:
                        log.warning(f"[Mic] Background STT error: {exc}")
                        time.sleep(1.0)
                except sr.WaitTimeoutError:
                    continue
                except Exception as exc:
                    if not self._bg_stop.is_set():
                        log.error(f"[Mic] Background listen error: {exc}")
                    time.sleep(0.5)
            log.info("[Mic] Background listener stopped")
            self._bg_running = False

        self._bg_thread = threading.Thread(target=_bg_loop, daemon=True, name="MicBackground")
        self._bg_thread.start()

    def stop_background_listen(self) -> None:
        """Stop the background listener."""
        if not self._bg_running:
            return
        self._bg_stop.set()
        if self._bg_thread and self._bg_thread.is_alive():
            self._bg_thread.join(timeout=2.0)
        self._bg_running = False
