"""Constants used across the ARJUN pipeline."""
from __future__ import annotations

# Pipeline stage names (for logging and events)
STAGE_STT = "stt"
STAGE_LLM = "llm"
STAGE_DISPATCHER = "dispatcher"
STAGE_ACTION = "action"
STAGE_TTS = "tts"

# Event names
EVENT_STT_COMPLETE = "stt.complete"
EVENT_STT_ERROR = "stt.error"
EVENT_LLM_COMPLETE = "llm.complete"
EVENT_LLM_ERROR = "llm.error"
EVENT_ACTION_COMPLETE = "action.complete"
EVENT_ACTION_ERROR = "action.error"
EVENT_TTS_COMPLETE = "tts.complete"
EVENT_TTS_ERROR = "tts.error"

# Default intents
INTENT_CONVERSATION = "conversation"
INTENT_UNKNOWN = "unknown"

# Browser process names for detection
BROWSER_PROCESSES = {
    "chrome":  ["chrome.exe", "chrome", "chromium"],
    "edge":    ["msedge.exe", "msedge"],
    "brave":   ["brave.exe", "brave"],
    "firefox": ["firefox.exe", "firefox"],
    "opera":   ["opera.exe", "opera"],
    "vivaldi": ["vivaldi.exe", "vivaldi"],
}

# Internal browser page URLs
INTERNAL_PAGES = {
    "chrome": {
        "settings": "chrome://settings", "downloads": "chrome://downloads",
        "history": "chrome://history", "extensions": "chrome://extensions",
        "bookmarks": "chrome://bookmarks",
    },
    "brave": {
        "settings": "brave://settings", "downloads": "brave://downloads",
        "history": "brave://history", "extensions": "brave://extensions",
        "bookmarks": "brave://bookmarks",
    },
    "edge": {
        "settings": "edge://settings", "downloads": "edge://downloads",
        "history": "edge://history", "extensions": "edge://extensions",
    },
}

# Common folder name aliases
FOLDER_ALIASES = {
    "downloads": "Downloads", "desktop": "Desktop",
    "documents": "Documents", "pictures": "Pictures",
    "videos": "Videos", "music": "Music",
}

# File categorization rules
FILE_CATEGORIES = {
    "Documents": ["pdf", "docx", "doc", "txt", "md", "rtf"],
    "Images": ["png", "jpg", "jpeg", "gif", "bmp", "svg", "webp"],
    "Videos": ["mp4", "mkv", "avi", "mov", "webm"],
    "Audio": ["mp3", "wav", "flac", "aac", "ogg"],
    "Archives": ["zip", "rar", "7z", "tar", "gz"],
    "Programming": ["py", "js", "ts", "java", "cpp", "c", "go", "rs", "rb"],
    "Data": ["json", "xml", "yaml", "yml", "csv", "sql"],
    "Web": ["html", "css", "scss"],
    "Others": [],
}
