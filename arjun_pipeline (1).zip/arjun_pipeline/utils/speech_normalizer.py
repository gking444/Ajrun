"""Speech normalization — converts spoken-word output to clean, parseable text.

Migrated from ARJUN_COMBINED_FIXED.py (source of truth).

ROOT-CAUSE FIX for the volume bug:
    "set volume to fifty percent"
     → normalize() →
    "set volume to 50 %"
     → extract_number() finds 50 → set_volume(50) ✅

Without this layer, "fifty" is invisible to RE_NUMBER = r'(\\d+)'.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple


class SpeechNormalizer:
    """Converts raw speech-recognition output to clean, machine-processable text."""

    _ONES: Dict[str, int] = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
        "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
        "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
        "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
        "eighteen": 18, "nineteen": 19,
    }
    _TENS: Dict[str, int] = {
        "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
        "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
    }
    _SCALES: Dict[str, int] = {
        "hundred": 100, "thousand": 1_000, "million": 1_000_000,
    }

    _ALL_NUM_WORDS: List[str] = sorted(
        list(_ONES) + list(_TENS) + list(_SCALES),
        key=len, reverse=True,
    )

    _WORD_NUM_PAT: re.Pattern = re.compile(
        r'\b(?:' + '|'.join(re.escape(w) for w in _ALL_NUM_WORDS) + r')'
        r'(?:(?:\s+|-)(?:and\s+)?(?:'
        + '|'.join(re.escape(w) for w in _ALL_NUM_WORDS) + r'))*\b',
        re.IGNORECASE,
    )

    _WAKE_WORDS: List[str] = [
        "hey arjun", "ok arjun", "okay arjun", "arjun",
        "hey jarvis", "ok jarvis", "okay jarvis", "jarvis", "hey",
    ]

    # (pattern, replacement) — applied before word-number conversion
    _SR_FIXES: List[Tuple[str, str]] = [
        (r'\bvolume\s+(?:two|to|too|tue|toe)\b', 'volume to'),
        (r'\bbrightness\s+(?:two|to|too)\b',     'brightness to'),
        (r'\bper\s+cent\b',                       'percent'),
        (r'\bpercent\b',                          '%'),
        (r'\borganised\b',                        'organize'),
        (r'\borganizd\b',                         'organize'),
        (r'\bganesh\b',                           'organize'),
        (r'\bby\s+data\b',                        'by date'),
        (r'\bvolume\s+ate\b',                     'volume 8'),
        (r'\bsett\b',                             'set'),
        (r'\bbrigtness\b',                        'brightness'),
    ]

    @classmethod
    def words_to_int(cls, phrase: str) -> Optional[int]:
        """Parse a spoken-number phrase into an integer.

        "fifty" → 50 | "twenty five" → 25 | "one hundred" → 100
        """
        words = [w for w in phrase.replace("-", " ").lower().split()
                 if w not in ("and", "a", "the")]
        if not words:
            return None
        current = result = 0
        for word in words:
            if word in cls._ONES:
                current += cls._ONES[word]
            elif word in cls._TENS:
                current += cls._TENS[word]
            elif word == "hundred":
                current = max(1, current) * 100
            elif word == "thousand":
                result += max(1, current) * 1_000; current = 0
            elif word == "million":
                result += max(1, current) * 1_000_000; current = 0
        return result + current

    @classmethod
    def _replace_word_numbers(cls, text: str) -> str:
        def _sub(m: "re.Match") -> str:
            val = cls.words_to_int(m.group(0))
            return str(val) if val is not None else m.group(0)
        return cls._WORD_NUM_PAT.sub(_sub, text)

    @classmethod
    def _strip_wake_word(cls, text: str) -> str:
        for wake in cls._WAKE_WORDS:
            if text.startswith(wake + " "):
                return text[len(wake):].strip()
            if text == wake:
                return ""
        return text

    @classmethod
    def _apply_sr_fixes(cls, text: str) -> str:
        for pattern, replacement in cls._SR_FIXES:
            text = re.sub(pattern, replacement, text, flags=re.I)
        return text

    @classmethod
    def normalize(cls, raw: str) -> str:
        """Full normalization pipeline.

        Input:  "Hey Arjun set volume to fifty percent"
        Output: "set volume to 50 %"
        """
        text = (raw or "").strip().lower()
        text = cls._strip_wake_word(text)
        text = cls._apply_sr_fixes(text)
        text = cls._replace_word_numbers(text)     # ← THE CRITICAL FIX
        return re.sub(r'\s+', ' ', text).strip()

    @classmethod
    def extract_number(cls, text: str, default: Optional[int] = None) -> Optional[int]:
        """Extract first number from already-normalized text.

        Always call normalize() BEFORE extract_number() for reliable results.
        """
        m = re.search(r'(\d+(?:\.\d+)?)', text)
        if m:
            return int(float(m.group(1)))
        val = cls.words_to_int(text)
        return val if val is not None else default
