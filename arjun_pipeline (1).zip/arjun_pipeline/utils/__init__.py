"""Utils package — helpers, validators, constants, speech normalizer."""
from .constants import (
    BROWSER_PROCESSES, EVENT_ACTION_COMPLETE, EVENT_ACTION_ERROR,
    EVENT_LLM_COMPLETE, EVENT_LLM_ERROR, EVENT_STT_COMPLETE, EVENT_STT_ERROR,
    EVENT_TTS_COMPLETE, EVENT_TTS_ERROR, FILE_CATEGORIES, FOLDER_ALIASES,
    INTERNAL_PAGES, INTENT_CONVERSATION, INTENT_UNKNOWN,
    STAGE_ACTION, STAGE_DISPATCHER, STAGE_LLM, STAGE_STT, STAGE_TTS,
)
from .helpers import categorize_file, is_linux, is_macos, is_windows, resolve_folder, safe_str
from .speech_normalizer import SpeechNormalizer
from .validators import (
    clamp, validate_brightness, validate_path, validate_required,
    validate_url, validate_volume,
)

__all__ = [
    "resolve_folder", "categorize_file", "is_windows", "is_macos", "is_linux", "safe_str",
    "validate_url", "validate_volume", "validate_brightness", "validate_path",
    "validate_required", "clamp",
    "SpeechNormalizer",
    "STAGE_STT", "STAGE_LLM", "STAGE_DISPATCHER", "STAGE_ACTION", "STAGE_TTS",
    "EVENT_STT_COMPLETE", "EVENT_STT_ERROR", "EVENT_LLM_COMPLETE", "EVENT_LLM_ERROR",
    "EVENT_ACTION_COMPLETE", "EVENT_ACTION_ERROR", "EVENT_TTS_COMPLETE", "EVENT_TTS_ERROR",
    "INTENT_CONVERSATION", "INTENT_UNKNOWN",
    "BROWSER_PROCESSES", "INTERNAL_PAGES", "FOLDER_ALIASES", "FILE_CATEGORIES",
]
