"""General utility helpers."""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional


def resolve_folder(name: Optional[str]) -> Path:
    """Resolve a folder name to a Path. Supports common aliases + absolute paths."""
    from .constants import FOLDER_ALIASES
    if not name:
        return Path.home() / "Downloads"
    name_lower = name.lower().strip()
    if name_lower in FOLDER_ALIASES:
        return Path.home() / FOLDER_ALIASES[name_lower]
    return Path(name).expanduser().resolve()


def categorize_file(filename: str) -> str:
    """Return the category name for a filename based on its extension."""
    from .constants import FILE_CATEGORIES
    ext = Path(filename).suffix.lower().lstrip(".")
    for category, exts in FILE_CATEGORIES.items():
        if ext in exts:
            return category
    return "Others"


def is_windows() -> bool:
    return sys.platform == "win32"


def is_macos() -> bool:
    return sys.platform == "darwin"


def is_linux() -> bool:
    return sys.platform.startswith("linux")


def safe_str(text: Any, max_len: int = 200) -> str:
    """Convert to string and truncate for logging."""
    s = str(text) if text is not None else ""
    return s[:max_len] + "..." if len(s) > max_len else s
