"""Input validation helpers for action parameters."""
from __future__ import annotations

from pathlib import Path
from typing import Any, List, Optional
from urllib.parse import urlparse


def validate_url(url: str) -> bool:
    """Return True if the string is a valid HTTP(S) URL."""
    if not url or not isinstance(url, str):
        return False
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        parsed = urlparse(url)
        return bool(parsed.scheme) and bool(parsed.netloc)
    except Exception:
        return False


def validate_volume(level: Any) -> bool:
    """Return True if level is an int/float in [0, 100]."""
    try:
        n = float(level)
        return 0 <= n <= 100
    except (TypeError, ValueError):
        return False


def validate_brightness(level: Any) -> bool:
    """Return True if level is an int/float in [0, 100]."""
    return validate_volume(level)


def validate_path(path: str) -> bool:
    """Return True if the path is a valid filesystem path string."""
    if not path or not isinstance(path, str):
        return False
    try:
        Path(path).expanduser()
        return True
    except Exception:
        return False


def validate_required(params: dict, required_keys: List[str]) -> Optional[str]:
    """Return the first missing required key, or None if all present."""
    for key in required_keys:
        if key not in params or params[key] is None or params[key] == "":
            return key
    return None


def clamp(value: Any, min_val: float, max_val: float) -> float:
    """Clamp a numeric value to [min_val, max_val]."""
    try:
        n = float(value)
        return max(min_val, min(max_val, n))
    except (TypeError, ValueError):
        return min_val
