"""Central configuration for the ARJUN pipeline.

All configurable values live here. Loaded from environment variables
with sensible defaults. No hard-coded values anywhere else in the codebase.

Migrated from the configuration sections of ARJUN_COMBINED_FIXED.py.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


@dataclass
class STTConfig:
    """Speech-to-Text configuration."""
    engine: str = "google"               # "google" | "whisper" | "sphinx"
    language: str = "en-US"
    timeout: float = 8.0                 # seconds to wait for speech to start
    phrase_time_limit: float = 20.0      # max seconds per phrase
    energy_threshold: int = 300          # mic sensitivity (migrated from VoiceCore)
    dynamic_energy: bool = True
    dynamic_energy_adjustment_ratio: float = 1.5  # migrated from VoiceCore
    pause_threshold: float = 1.2         # migrated from VoiceCore
    phrase_threshold: float = 0.3        # migrated from VoiceCore
    non_speaking_duration: float = 0.8   # migrated from VoiceCore
    operation_timeout: int = 15          # migrated from VoiceCore
    noise_reduction: bool = True


@dataclass
class TTSConfig:
    """Text-to-Speech configuration."""
    engine: str = "pyttsx3"              # "pyttsx3" | "edge-tts"
    voice_rate: int = 180                # words per minute (migrated from TTSCore)
    voice_volume: float = 1.0            # 0.0 - 1.0
    voice_id: Optional[str] = None       # None = auto-select preferred voice
    blocking: bool = False               # default non-blocking for barge-in


@dataclass
class LLMConfig:
    """LLM configuration — migrated from AIGateway settings."""
    backend: str = "ollama"              # auto-detected, can be forced
    base_url: str = "http://localhost:11434"
    model: str = "llama3.2"
    api_key: Optional[str] = None
    temperature: float = 0.3             # low for deterministic intent extraction
    max_tokens: int = 2048               # migrated from AIGateway default
    timeout: float = 120.0               # migrated from AIGateway (120s for local LLMs)
    max_history: int = 20                # conversation history window
    # Confidence threshold: if the LLM's confidence is below this, the
    # dispatcher asks the user to clarify instead of executing.
    confidence_threshold: float = 0.6


@dataclass
class MemoryConfig:
    """Conversation memory configuration."""
    max_messages: int = 20               # rolling window of recent messages
    max_tokens: int = 2000               # token budget for context window
    persist_path: Optional[Path] = None  # None = in-memory only


@dataclass
class AudioConfig:
    """Audio hardware configuration."""
    microphone_index: Optional[int] = None  # None = system default
    sample_rate: int = 16000
    chunk_size: int = 1024
    vad_aggressiveness: int = 3          # 0-3, higher = more aggressive


@dataclass
class LogConfig:
    """Logging configuration."""
    level: str = "INFO"
    file_path: Optional[Path] = None
    format: str = "%(asctime)s | %(levelname)-7s | %(name)-20s | %(message)s"
    date_format: str = "%Y-%m-%d %H:%M:%S"


@dataclass
class PipelineConfig:
    """Top-level configuration aggregating all subsystem configs."""
    stt: STTConfig = field(default_factory=STTConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    audio: AudioConfig = field(default_factory=AudioConfig)
    logging: LogConfig = field(default_factory=LogConfig)

    # Wake word (empty = always listening)
    wake_word: str = ""

    # Exit words that stop the main loop
    exit_words: List[str] = field(default_factory=lambda: [
        "quit", "exit", "goodbye", "bye", "farewell",
        "close arjun", "shutdown arjun"
    ])

    # Stop words that interrupt TTS (migrated from the working Python file)
    stop_words: List[str] = field(default_factory=lambda: [
        "stop", "quiet", "shut up", "silence", "hush", "enough"
    ])

    # Confirmation policy for destructive actions
    require_confirmation: bool = True
    confirmation_timeout: float = 15.0

    @classmethod
    def from_env(cls) -> "PipelineConfig":
        """Load configuration from environment variables."""
        cfg = cls()

        # STT
        cfg.stt.engine = os.getenv("ARJUN_STT_ENGINE", cfg.stt.engine)
        cfg.stt.language = os.getenv("ARJUN_STT_LANGUAGE", cfg.stt.language)
        cfg.stt.energy_threshold = int(os.getenv("ARJUN_STT_ENERGY_THRESHOLD", cfg.stt.energy_threshold))

        # TTS
        cfg.tts.engine = os.getenv("ARJUN_TTS_ENGINE", cfg.tts.engine)
        cfg.tts.voice_rate = int(os.getenv("ARJUN_TTS_RATE", cfg.tts.voice_rate))

        # LLM
        cfg.llm.backend = os.getenv("ARJUN_LLM_BACKEND", cfg.llm.backend)
        cfg.llm.base_url = os.getenv("ARJUN_LLM_BASE_URL", cfg.llm.base_url)
        cfg.llm.model = os.getenv("ARJUN_LLM_MODEL", cfg.llm.model)
        cfg.llm.api_key = os.getenv("ARJUN_LLM_API_KEY")
        cfg.llm.confidence_threshold = float(
            os.getenv("ARJUN_LLM_CONFIDENCE_THRESHOLD", cfg.llm.confidence_threshold)
        )
        cfg.llm.max_history = int(os.getenv("ARJUN_LLM_MAX_HISTORY", cfg.llm.max_history))

        # Audio
        mic_idx = os.getenv("ARJUN_MIC_INDEX")
        if mic_idx:
            cfg.audio.microphone_index = int(mic_idx)

        # Wake word
        cfg.wake_word = os.getenv("ARJUN_WAKE_WORD", "").lower()

        # Logging
        cfg.logging.level = os.getenv("ARJUN_LOG_LEVEL", cfg.logging.level)
        log_file = os.getenv("ARJUN_LOG_FILE")
        if log_file:
            cfg.logging.file_path = Path(log_file)

        return cfg
