"""Structured logging for the ARJUN pipeline.

Every pipeline stage logs its entry, exit, and any errors with timestamps
and log levels. Logs go to both console and an optional rotating file.
"""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from typing import Optional

from .config import LogConfig

_CONFIGURED = False


def configure_logging(config: LogConfig) -> None:
    """Configure the root 'arjun' logger once."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    root = logging.getLogger("arjun")
    root.setLevel(logging.DEBUG)
    root.propagate = False

    fmt = logging.Formatter(config.format, datefmt=config.date_format)

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(getattr(logging, config.level.upper(), logging.INFO))
    ch.setFormatter(fmt)
    root.addHandler(ch)

    # File handler (optional, rotating 5x1MB)
    if config.file_path:
        try:
            config.file_path.parent.mkdir(parents=True, exist_ok=True)
            fh = RotatingFileHandler(
                config.file_path, maxBytes=1_000_000, backupCount=5, encoding="utf-8"
            )
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(fmt)
            root.addHandler(fh)
        except (PermissionError, OSError):
            pass  # console-only is fine

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a child logger under the 'arjun' namespace."""
    if not name.startswith("arjun"):
        name = f"arjun.{name}"
    return logging.getLogger(name)
