"""Custom exceptions for the ARJUN pipeline.

Each pipeline stage has its own exception type so callers can catch
errors at the appropriate granularity.
"""
from __future__ import annotations


class ArjunError(Exception):
    """Base exception for all ARJUN pipeline errors."""


# ── STT errors ────────────────────────────────────────────────────────────────
class STTError(ArjunError):
    """Base error for Speech-to-Text failures."""


class STTUnavailableError(STTError):
    """STT engine is not installed or configured."""


class MicrophoneError(STTError):
    """Microphone hardware/access error."""


class RecognitionError(STTError):
    """Speech was captured but could not be recognized."""


# ── LLM errors ────────────────────────────────────────────────────────────────
class LLMError(ArjunError):
    """Base error for LLM failures."""


class LLMUnavailableError(LLMError):
    """No LLM backend is available."""


class LLMResponseError(LLMError):
    """LLM returned an unparseable response."""


# ── Action errors ─────────────────────────────────────────────────────────────
class ActionError(ArjunError):
    """Base error for action execution failures."""


class UnknownActionError(ActionError):
    """The LLM returned an intent that no action module can handle."""


class ActionValidationError(ActionError):
    """Action parameters failed validation."""


class ActionExecutionError(ActionError):
    """Action was valid but failed during execution."""


# ── TTS errors ────────────────────────────────────────────────────────────────
class TTSError(ArjunError):
    """Base error for Text-to-Speech failures."""


class TTSUnavailableError(TTSError):
    """TTS engine is not installed."""


# ── Config errors ─────────────────────────────────────────────────────────────
class ConfigError(ArjunError):
    """Configuration is missing or invalid."""
