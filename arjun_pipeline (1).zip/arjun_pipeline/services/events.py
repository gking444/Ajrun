"""Event system for the ARJUN pipeline.

Allows pipeline stages to emit events (e.g. "stt.complete", "action.executed")
that other components can subscribe to. Used for metrics, dashboard updates,
and audit logging.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .logger import get_logger

log = get_logger("events")


@dataclass
class Event:
    """A single pipeline event."""
    name: str
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class EventBus:
    """In-memory pub/sub event bus."""

    def __init__(self) -> None:
        self._subscribers: Dict[str, List[Callable[[Event], None]]] = {}

    def subscribe(self, event_name: str, callback: Callable[[Event], None]) -> None:
        """Subscribe to an event by name."""
        self._subscribers.setdefault(event_name, []).append(callback)
        log.debug(f"Subscribed to '{event_name}'")

    def emit(self, event_name: str, **data: Any) -> None:
        """Emit an event. All subscribers are called synchronously."""
        event = Event(name=event_name, data=data)
        for callback in self._subscribers.get(event_name, []):
            try:
                callback(event)
            except Exception as exc:
                log.error(f"Event subscriber error for '{event_name}': {exc}")
        # Also emit to wildcard subscribers
        for callback in self._subscribers.get("*", []):
            try:
                callback(event)
            except Exception as exc:
                log.error(f"Wildcard subscriber error: {exc}")


# Singleton event bus
_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """Return the singleton event bus."""
    global _bus
    if _bus is None:
        _bus = EventBus()
    return _bus
