"""Cancellation token for cooperative task cancellation.

Used to cancel in-progress LLM generation and TTS playback when the
user interrupts (barge-in). Per spec rule 8:
  "If response generation is still in progress when the user interrupts,
   cancel the generation immediately and start processing the new request."
"""
from __future__ import annotations

import threading


class CancellationToken:
    """Thread-safe cooperative cancellation flag."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        """Signal cancellation to all holders of this token."""
        self._event.set()

    @property
    def cancelled(self) -> bool:
        """True if cancel() has been called."""
        return self._event.is_set()

    def reset(self) -> None:
        """Clear the cancellation flag for reuse."""
        self._event.clear()
