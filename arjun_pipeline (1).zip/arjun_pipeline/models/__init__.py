"""Data models for the ARJUN pipeline.

Every pipeline stage uses typed dataclasses for input/output, ensuring
clean contracts between STT, LLM, Dispatcher, Actions, and TTS.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class STTResult:
    """Output of the Speech-to-Text stage."""
    text: str
    confidence: float = 1.0
    language: str = "en-US"
    timestamp: float = field(default_factory=time.time)
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.error is None and bool(self.text)


@dataclass
class LLMIntent:
    """Structured output from the LLM router.

    The LLM is the central reasoning engine. It receives the user's text
    and returns this structured object with:
      - intent: a dotted action name (e.g. "browser.search", "system.set_volume")
      - parameters: dict of action-specific parameters
      - response: the text to speak back to the user
      - confidence: 0.0-1.0 — if below threshold, dispatcher asks for clarification
      - needs_clarification: True if the LLM is unsure and is asking a follow-up
      - clarification_options: list of options presented to the user (if any)
    """
    intent: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    response: str = ""
    confidence: float = 1.0
    needs_clarification: bool = False
    clarification_options: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.error is None and bool(self.intent)

    @property
    def is_conversation(self) -> bool:
        """True if this is a conversational response (no action to execute)."""
        return self.intent in ("conversation", "unknown", "") or self.needs_clarification


@dataclass
class ActionResult:
    """Output of the Action execution stage."""
    success: bool
    message: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    elapsed_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success, "message": self.message,
            "data": self.data, "error": self.error,
            "elapsed_ms": self.elapsed_ms,
        }


@dataclass
class ConversationMessage:
    """A single message in the conversation history."""
    role: str  # "user" | "assistant" | "system"
    content: str
    timestamp: float = field(default_factory=time.time)
    intent: Optional[str] = None       # for assistant messages
    action_result: Optional[bool] = None  # for assistant messages


@dataclass
class PipelineResult:
    """End-to-end pipeline result (for logging/metrics)."""
    stt: Optional[STTResult] = None
    llm: Optional[LLMIntent] = None
    action: Optional[ActionResult] = None
    tts_spoken: bool = False
    total_elapsed_ms: int = 0

    @property
    def success(self) -> bool:
        return (self.stt is not None and self.stt.success and
                self.llm is not None and self.llm.success)
