"""Tests for real-time interruption (barge-in) and clarification features."""
from __future__ import annotations

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from unittest.mock import MagicMock, patch

from services import CancellationToken
from models import LLMIntent, STTResult, ActionResult


class TestCancellationToken(unittest.TestCase):
    """Tests for the CancellationToken cooperative cancellation."""

    def test_initial_state(self):
        token = CancellationToken()
        self.assertFalse(token.cancelled)

    def test_cancel(self):
        token = CancellationToken()
        token.cancel()
        self.assertTrue(token.cancelled)

    def test_reset(self):
        token = CancellationToken()
        token.cancel()
        token.reset()
        self.assertFalse(token.cancelled)


class TestLLMIntentClarification(unittest.TestCase):
    """Tests for the clarification fields on LLMIntent."""

    def test_default_no_clarification(self):
        intent = LLMIntent(intent="browser.search", response="Searching.")
        self.assertFalse(intent.needs_clarification)
        self.assertEqual(intent.clarification_options, [])
        self.assertFalse(intent.is_conversation)

    def test_with_clarification(self):
        intent = LLMIntent(
            intent="conversation",
            response="Which file do you mean?",
            needs_clarification=True,
            clarification_options=["file A", "file B"],
        )
        self.assertTrue(intent.needs_clarification)
        self.assertEqual(len(intent.clarification_options), 2)
        # An intent needing clarification is treated as conversation
        # (no action to execute)
        self.assertTrue(intent.is_conversation)


class TestTTSCancel(unittest.TestCase):
    """Tests for the TTS engine's cancel() method."""

    def test_cancel_stops_speech_flag(self):
        """cancel() should clear the is_speaking flag."""
        from audio.tts import TTSEngine
        from services.config import TTSConfig
        tts = TTSEngine(TTSConfig())
        if not tts.available:
            self.skipTest("TTS not available")
        # Start non-blocking speech
        tts.speak("This is a test sentence.", blocking=False)
        # Cancel immediately
        tts.cancel()
        # The is_speaking flag should be cleared shortly
        import time
        time.sleep(0.6)
        self.assertFalse(tts.is_speaking)


class TestMicrophoneBackgroundListen(unittest.TestCase):
    """Tests for the microphone background listener."""

    def test_background_listen_api(self):
        """The microphone should expose listen_in_background / stop."""
        from audio.microphone import Microphone
        from services.config import AudioConfig, STTConfig
        mic = Microphone(AudioConfig(), STTConfig())
        if not mic.available:
            self.skipTest("Microphone not available")
        self.assertFalse(mic.background_listening)
        # Start
        mic.listen_in_background(lambda text: None)
        self.assertTrue(mic.background_listening)
        # Stop
        mic.stop_background_listen()
        self.assertFalse(mic.background_listening)


class TestRouterCancellation(unittest.TestCase):
    """Tests for the LLM router's cancellation support."""

    def test_cancelled_token_returns_cancelled_intent(self):
        """If the cancel token is already cancelled, router returns immediately."""
        from llm.router import LLMRouter
        from llm.conversation import Conversation
        from services.config import LLMConfig, MemoryConfig

        conv = Conversation(LLMConfig(), MemoryConfig())
        router = LLMRouter(conv, LLMConfig())

        token = CancellationToken()
        token.cancel()

        result = router.route("open chrome", cancel_token=token)
        self.assertEqual(result.error, "cancelled")
        self.assertEqual(result.confidence, 0.0)


class TestBargeInFlow(unittest.TestCase):
    """Tests for the main pipeline's barge-in flow."""

    def test_barge_in_sets_interrupt_event(self):
        """_on_barge_in should set the interrupt event and store text."""
        from main import ArjunPipeline
        from services import PipelineConfig

        pipeline = ArjunPipeline(PipelineConfig())
        pipeline._on_barge_in("stop talking")
        self.assertTrue(pipeline._interrupt_event.is_set())
        self.assertEqual(pipeline._last_user_text, "stop talking")


if __name__ == "__main__":
    unittest.main()
