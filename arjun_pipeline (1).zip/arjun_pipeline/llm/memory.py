"""Conversation memory — rolling history of user/assistant messages.

The LLM router receives recent history for context. Token limits are
respected by trimming old messages.
"""
from __future__ import annotations

import threading
from typing import List, Optional

from models import ConversationMessage
from services.config import MemoryConfig
from services.logger import get_logger

log = get_logger("llm.memory")


class ConversationMemory:
    """Thread-safe rolling conversation history."""

    def __init__(self, config: MemoryConfig):
        self._config = config
        self._messages: List[ConversationMessage] = []
        self._lock = threading.Lock()

    def add_user(self, content: str) -> None:
        """Add a user message."""
        with self._lock:
            self._messages.append(ConversationMessage(role="user", content=content))
            self._trim()

    def add_assistant(self, content: str, intent: Optional[str] = None,
                      action_result: Optional[bool] = None) -> None:
        """Add an assistant message."""
        with self._lock:
            self._messages.append(ConversationMessage(
                role="assistant", content=content,
                intent=intent, action_result=action_result
            ))
            self._trim()

    def add_system(self, content: str) -> None:
        """Add a system message."""
        with self._lock:
            self._messages.append(ConversationMessage(role="system", content=content))
            self._trim()

    def get_history(self, max_messages: Optional[int] = None) -> List[dict]:
        """Return conversation history as a list of dicts for the LLM.

        Args:
            max_messages: Override the configured max. None = use config.

        Returns:
            List of {"role": "...", "content": "..."} dicts.
        """
        limit = max_messages or self._config.max_messages
        with self._lock:
            recent = self._messages[-limit:]
            return [{"role": m.role, "content": m.content} for m in recent]

    def clear(self) -> None:
        """Clear all history."""
        with self._lock:
            self._messages.clear()

    def _trim(self) -> None:
        """Trim the history to max_messages."""
        if len(self._messages) > self._config.max_messages:
            self._messages = self._messages[-self._config.max_messages:]
