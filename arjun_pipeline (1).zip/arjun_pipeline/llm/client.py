"""LLM API client — migrated from ARJUN_COMBINED_FIXED.py.

Local-only AI gateway. Auto-discovers any running local inference server
(Ollama, LM Studio, Jan, vLLM, Ooba, llama.cpp, GPT4All, KoboldCpp, llamafile)
and routes chat completions to it. NO cloud APIs are ever contacted.

Migrated from AIGateway in the working Python file. Public API preserved:
  • query(prompt)            → (ok, response)  — single-turn
  • chat(prompt, system=, max_tokens=) → (ok, response) — multi-turn
  • list_models()            → formatted string of available local models
  • set_model(name)          → switch active model
  • set_backend(name)        → switch active backend
  • discover_backends()      → re-probe all known local servers
  • clear_history()
  • verify_model_available() → check model is still on backend
  • current_status()         → human-readable status

Also provides a chat_completion() method that takes a list of messages
(OpenAI-style) for use by the LLM router.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.request import Request, urlopen
from urllib.error import URLError

from services.config import LLMConfig
from services.exceptions import LLMUnavailableError
from services.logger import get_logger

log = get_logger("llm.client")

try:
    import requests
    REQ_OK = True
except ImportError:
    REQ_OK = False


class LLMClient:
    """Local-only LLM API client.

    Migrated from AIGateway in ARJUN_COMBINED_FIXED.py.
    """

    # All known local backends. The URL is the base URL; for OpenAI-compat
    # backends we append /v1/chat/completions. For Ollama we use /api/chat.
    _LOCAL_BACKENDS: Dict[str, Dict] = {
        "ollama": {
            "base_url":  "http://localhost:11434",
            "api_style": "ollama",
            "desc":      "Ollama — easiest local LLM runtime (https://ollama.com)",
        },
        "lmstudio": {
            "base_url":  "http://localhost:1234",
            "api_style": "openai",
            "desc":      "LM Studio — GUI-based local model runner",
        },
        "jan": {
            "base_url":  "http://localhost:1337",
            "api_style": "openai",
            "desc":      "Jan — open-source ChatGPT alternative",
        },
        "vllm": {
            "base_url":  "http://localhost:8000",
            "api_style": "openai",
            "desc":      "vLLM — high-throughput inference server",
        },
        "ooba": {
            "base_url":  "http://localhost:5000",
            "api_style": "openai",
            "desc":      "text-generation-webui (OpenAI extension)",
        },
        "llamacpp": {
            "base_url":  "http://localhost:8080",
            "api_style": "openai",
            "desc":      "llama.cpp server (OpenAI-compatible build)",
        },
        "gpt4all": {
            "base_url":  "http://localhost:4891",
            "api_style": "openai",
            "desc":      "GPT4All — desktop local LLM runtime (https://gpt4all.io)",
        },
        "koboldcpp": {
            "base_url":  "http://localhost:5001",
            "api_style": "openai",
            "desc":      "KoboldCpp — lightweight local LLM runtime",
        },
        "llamafile": {
            "base_url":  "http://localhost:8080",
            "api_style": "openai",
            "desc":      "llamafile — single-file LLM distribution",
        },
    }

    _CACHE_DIR = Path.home() / ".arjun"
    _CACHE_FILE = _CACHE_DIR / "ai_model_cache.json"

    def __init__(self, config: LLMConfig):
        self._config = config
        self._model: Optional[str] = None
        self._backend: Optional[str] = None
        self._history: List[Dict] = []
        self._max_history = 20
        self._system_prompt = (
            "You are ARJUN, an advanced AI assistant running entirely locally "
            "on the user's laptop. Be helpful, concise, and accurate. "
            "If asked to perform system actions, describe what you would do clearly."
        )
        self._discovered_models: Dict[str, List[str]] = {}

        # Allow env-var override for backend URLs
        for name, cfg in self._LOCAL_BACKENDS.items():
            env_var = f"{name.upper()}_URL"
            if os.environ.get(env_var):
                cfg["base_url"] = os.environ[env_var].rstrip("/")

        # Allow forcing a backend via env var or config
        forced = (os.environ.get("ARJUN_AI_BACKEND", "") or config.backend).strip().lower()
        if forced and forced in self._LOCAL_BACKENDS:
            self._backend = forced

        # Try loading cached backend+model
        self._load_cache()

        # If config specifies a model, use it
        if config.model and not self._model:
            self._model = config.model

        # Discover on init (best-effort)
        try:
            self.discover_backends()
        except Exception as exc:
            log.warning(f"[AIGateway] discovery failed: {exc}")

    # ════════════════════════════════════════════════════════════════
    # PUBLIC API (preserved from AIGateway)
    # ════════════════════════════════════════════════════════════════

    @property
    def backend(self) -> Optional[str]:
        return self._backend

    @property
    def model(self) -> Optional[str]:
        return self._model

    @property
    def available(self) -> bool:
        """Quick check if the active backend is reachable."""
        if not self._backend:
            return False
        return self._probe_backend(self._backend)

    def set_model(self, name: str) -> Tuple[bool, str]:
        """Switch the active model."""
        name = name.strip()
        if not name:
            return False, "Empty model name"
        if self._backend:
            available = self._discovered_models.get(self._backend, [])
            match = next((m for m in available if name.lower() in m.lower()), None)
            if match:
                self._model = match
                self._save_cache()
                return True, f"AI model set to: {match} (backend: {self._backend})"
            self._model = name
            self._save_cache()
            return True, f"AI model set to: {name} (not in discovered list — will try)"
        self._model = name
        self._save_cache()
        return True, f"AI model set to: {name} (no backend active yet)"

    def set_backend(self, name: str) -> Tuple[bool, str]:
        """Switch the active backend."""
        name = name.strip().lower()
        if name not in self._LOCAL_BACKENDS:
            available = ", ".join(self._LOCAL_BACKENDS.keys())
            return False, f"Unknown backend '{name}'. Available: {available}"
        if not self._probe_backend(name):
            return False, f"{name} not reachable at {self._LOCAL_BACKENDS[name]['base_url']}"
        self._backend = name
        self._refresh_model_list(name)
        if self._discovered_models.get(name):
            if not self._model or self._model not in self._discovered_models[name]:
                self._model = self._discovered_models[name][0]
        self._save_cache()
        return True, f"Active backend: {name} ({self._LOCAL_BACKENDS[name]['base_url']})"

    def list_models(self) -> str:
        """Return a formatted string of available local models."""
        lines = ["\nLocal AI Models (no cloud):\n"]
        if not self._backend:
            lines.append("  No local backend detected.")
            lines.append("  Install one of:")
            for name, cfg in self._LOCAL_BACKENDS.items():
                lines.append(f"    - {name:<10} — {cfg['desc']}")
            return "\n".join(lines)
        lines.append(f"  Active backend: {self._backend}")
        lines.append(f"  URL: {self._LOCAL_BACKENDS[self._backend]['base_url']}\n")
        models = self._discovered_models.get(self._backend, [])
        if not models:
            lines.append("  (no models loaded on this backend)")
        else:
            for m in models:
                marker = " <== active" if m == self._model else ""
                lines.append(f"    - {m}{marker}")
        return "\n".join(lines)

    def clear_history(self) -> Tuple[bool, str]:
        self._history.clear()
        return True, "Conversation history cleared"

    def discover_backends(self) -> Dict[str, bool]:
        """Probe every known local backend URL. Returns {name: reachable}."""
        results: Dict[str, bool] = {}
        for name in self._LOCAL_BACKENDS:
            results[name] = self._probe_backend(name)
        # Auto-pick a backend if none is active
        if not self._backend or not results.get(self._backend, False):
            for name, ok in results.items():
                if ok:
                    self._backend = name
                    self._refresh_model_list(name)
                    if not self._model and self._discovered_models.get(name):
                        self._model = self._discovered_models[name][0]
                    log.info(f"[AIGateway] auto-selected backend: {name}")
                    break
        log.info(f"[AIGateway] discovery results: {results}")
        return results

    def verify_model_available(self, model: Optional[str] = None,
                                backend: Optional[str] = None) -> bool:
        """Check that the given (or active) model is currently available."""
        b = backend or self._backend
        m = model or self._model
        if not b or not m:
            return False
        self._refresh_model_list(b)
        available = self._discovered_models.get(b, [])
        if not available:
            return False
        if m in available:
            return True
        m_lower = m.lower()
        for a in available:
            if a.lower() == m_lower:
                return True
        for a in available:
            if m_lower in a.lower() or a.lower() in m_lower:
                return True
        return False

    def current_status(self) -> str:
        """Human-readable status of the active backend + model."""
        if not self._backend:
            return "No local AI backend detected."
        display = self._LOCAL_BACKENDS[self._backend].get("desc", self._backend)
        url = self._LOCAL_BACKENDS[self._backend].get("base_url", "")
        model = self._model or "(none selected)"
        return (
            f"Active backend: {self._backend} — {display}\n"
            f"  URL:   {url}\n"
            f"  Model: {model}"
        )

    # ════════════════════════════════════════════════════════════════
    # QUERY / CHAT ENTRY POINTS (preserved from AIGateway)
    # ════════════════════════════════════════════════════════════════

    def query(self, user_input: str, stream_callback: Callable = None) -> Tuple[bool, str]:
        """Single-turn query (also appends to internal history)."""
        if not user_input.strip():
            return False, "Empty query"
        return self._do_chat(user_input, system=self._system_prompt, max_tokens=2048)

    def chat(self, user_input: str, system: Optional[str] = None,
             max_tokens: int = 2048) -> Tuple[bool, str]:
        """Multi-turn chat with optional system prompt override."""
        if not user_input.strip():
            return False, "Empty query"
        return self._do_chat(user_input, system=system, max_tokens=max_tokens)

    def chat_completion(self, messages: List[Dict[str, str]],
                        temperature: float = 0.3) -> str:
        """OpenAI-style chat completion — takes a list of messages.

        Used by the LLM router. Returns the text response directly.
        Raises LLMUnavailableError if no backend is reachable.
        """
        if not self._backend:
            self.discover_backends()
        if not self._backend:
            raise LLMUnavailableError(
                "No local AI backend detected. Install Ollama/LM Studio/etc."
            )

        cfg = self._LOCAL_BACKENDS[self._backend]
        model = self._active_model()
        try:
            if cfg["api_style"] == "ollama":
                return self._ollama_chat(messages, model, cfg["base_url"])
            else:
                return self._openai_compat_chat(messages, model, cfg["base_url"],
                                                max_tokens=self._config.max_tokens)
        except ConnectionError as exc:
            raise LLMUnavailableError(str(exc))
        except Exception as exc:
            log.error(f"[AIGateway] chat_completion failed [{self._backend}/{model}]: {exc}")
            raise

    # ════════════════════════════════════════════════════════════════
    # INTERNAL HELPERS (preserved from AIGateway)
    # ════════════════════════════════════════════════════════════════

    def _probe_backend(self, name: str) -> bool:
        """Quick health-check probe (2-second timeout)."""
        cfg = self._LOCAL_BACKENDS.get(name)
        if not cfg:
            return False
        base = cfg["base_url"]
        style = cfg["api_style"]
        try:
            if style == "ollama":
                url = f"{base}/api/tags"
            else:
                url = f"{base}/v1/models"
            req = Request(url, headers={"Content-Type": "application/json"})
            with urlopen(req, timeout=2) as resp:
                if resp.status == 200:
                    return True
            return False
        except Exception:
            return False

    def _refresh_model_list(self, name: str) -> None:
        """Fetch the list of models available on the given backend."""
        cfg = self._LOCAL_BACKENDS.get(name)
        if not cfg:
            return
        base = cfg["base_url"]
        style = cfg["api_style"]
        models: List[str] = []
        try:
            if style == "ollama":
                url = f"{base}/api/tags"
                req = Request(url)
                with urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read())
                models = [m.get("name", "") for m in data.get("models", []) if m.get("name")]
            else:
                url = f"{base}/v1/models"
                req = Request(url, headers={"Content-Type": "application/json"})
                with urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read())
                models = [m.get("id", "") for m in data.get("data", []) if m.get("id")]
        except Exception as exc:
            log.warning(f"[AIGateway] model list fetch failed for {name}: {exc}")
        self._discovered_models[name] = models

    def _active_model(self) -> str:
        if self._model:
            return self._model
        if self._backend == "ollama":
            return "llama3.2"
        return "local-model"

    def _ollama_chat(self, messages: List[Dict], model: str, base_url: str) -> str:
        url = f"{base_url}/api/chat"
        payload = json.dumps({
            "model":    model,
            "messages": messages,
            "stream":   False,
        }).encode()
        req = Request(url, data=payload, headers={"Content-Type": "application/json"})
        try:
            with urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read())
                return data.get("message", {}).get("content", "No response")
        except URLError as exc:
            raise ConnectionError(f"Ollama not reachable at {base_url}: {exc}")

    def _openai_compat_chat(self, messages: List[Dict], model: str,
                             base_url: str, max_tokens: int = 2048) -> str:
        if not REQ_OK:
            # Fall back to urllib if requests is unavailable
            url = f"{base_url}/v1/chat/completions"
            payload = json.dumps({
                "model": model,
                "messages": messages,
                "max_tokens": max_tokens,
                "stream": False,
            }).encode()
            req = Request(url, data=payload, headers={"Content-Type": "application/json"})
            with urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read())
            return data["choices"][0]["message"]["content"]
        url = f"{base_url}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}
        if self._config.api_key:
            headers["Authorization"] = f"Bearer {self._config.api_key}"
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "stream": False,
        }
        resp = requests.post(url, headers=headers, json=payload, timeout=120)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    def _do_chat(self, user_input: str, system: Optional[str],
                 max_tokens: int) -> Tuple[bool, str]:
        """Internal multi-turn chat (preserved from AIGateway._do_chat)."""
        # Update history
        self._history.append({"role": "user", "content": user_input})
        max_entries = self._max_history * 2
        if len(self._history) > max_entries:
            self._history = self._history[-max_entries:]
        while self._history and self._history[0]["role"] != "user":
            self._history.pop(0)

        sys_prompt = system or self._system_prompt
        messages = [{"role": "system", "content": sys_prompt}] + self._history

        # No backend available → clear error
        if not self._backend:
            self.discover_backends()
        if not self._backend:
            install_hints = (
                "\n\nNO LOCAL AI BACKEND DETECTED.\n"
                "ARJUN refuses to use cloud APIs per privacy setting.\n"
                "To enable AI, install ONE of these local runtimes:\n"
                "  - Ollama       → https://ollama.com        then: ollama serve\n"
                "  - LM Studio    → https://lmstudio.ai       (start the local server)\n"
                "  - GPT4All      → https://gpt4all.io         (enable API server)\n"
                "  - Jan          → https://jan.ai            (enable the API server)\n"
                "  - vLLM         → pip install vllm\n"
                "  - llama.cpp    → https://github.com/ggerganov/llama.cpp\n"
                "  - KoboldCpp    → https://github.com/LostRuins/koboldcpp\n"
                "After starting one, say: 'discover ai backends' or restart ARJUN."
            )
            return False, install_hints

        # Verify the cached/active model is still available
        if not self.verify_model_available():
            avail = self._discovered_models.get(self._backend, [])
            if avail:
                msg = (
                    f"The selected AI model '{self._model}' is no longer available "
                    f"on backend '{self._backend}'.\n"
                    f"Available models:\n" + "\n".join(f"  - {m}" for m in avail) +
                    "\nSay 'switch ai model' to choose another."
                )
            else:
                msg = (
                    f"The selected AI model '{self._model}' is no longer available "
                    f"on backend '{self._backend}'.\n"
                    f"Say 'discover ai backends' after starting a local server."
                )
            self._model = None
            self._clear_cache()
            return False, msg

        cfg = self._LOCAL_BACKENDS[self._backend]
        model = self._active_model()
        try:
            if cfg["api_style"] == "ollama":
                response = self._ollama_chat(messages, model, cfg["base_url"])
            else:
                response = self._openai_compat_chat(
                    messages, model, cfg["base_url"], max_tokens=max_tokens
                )
            self._history.append({"role": "assistant", "content": response})
            return True, response
        except ConnectionError as exc:
            msg = (
                f"Local backend '{self._backend}' not reachable: {exc}\n"
                f"   URL: {cfg['base_url']}\n"
                f"   Start it, then say 'discover ai backends'."
            )
            log.error(msg)
            return False, msg
        except Exception as exc:
            log.error(f"[AIGateway] chat failed [{self._backend}/{model}]: {exc}")
            return False, f"AI error ({self._backend}/{model}): {exc}"

    # ════════════════════════════════════════════════════════════════
    # PERSISTENT CACHE (preserved from AIGateway)
    # ════════════════════════════════════════════════════════════════

    def _load_cache(self) -> None:
        """Load cached backend+model from disk, if present and still valid."""
        try:
            if self._CACHE_FILE.exists():
                with open(self._CACHE_FILE, "r") as f:
                    data = json.load(f)
                cached_backend = data.get("backend")
                cached_model = data.get("model")
                cached_ts = data.get("timestamp", 0)
                if time.time() - cached_ts > 7 * 86400:
                    log.info("[AIGateway] cache expired (>7 days), re-verifying")
                    return
                if cached_backend and cached_backend in self._LOCAL_BACKENDS:
                    self._backend = cached_backend
                    self._model = cached_model
                    log.info(f"[AIGateway] loaded cache: backend={cached_backend} model={cached_model}")
        except Exception as exc:
            log.warning(f"[AIGateway] cache load failed: {exc}")

    def _save_cache(self) -> None:
        """Persist the current backend+model to disk."""
        try:
            self._CACHE_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "backend": self._backend,
                "model": self._model,
                "timestamp": time.time(),
            }
            with open(self._CACHE_FILE, "w") as f:
                json.dump(data, f, indent=2)
            log.info(f"[AIGateway] saved cache: backend={self._backend} model={self._model}")
        except Exception as exc:
            log.warning(f"[AIGateway] cache save failed: {exc}")

    def _clear_cache(self) -> None:
        """Delete the cache file (used when model becomes unavailable)."""
        try:
            if self._CACHE_FILE.exists():
                self._CACHE_FILE.unlink()
                log.info("[AIGateway] cache cleared")
        except Exception as exc:
            log.warning(f"[AIGateway] cache clear failed: {exc}")
