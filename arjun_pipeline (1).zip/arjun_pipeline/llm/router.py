"""LLM Router — the central reasoning engine.

Receives the user's text, sends it to the LLM, parses the structured
JSON response, and returns an LLMIntent. If the LLM is unavailable or
returns unparseable output, falls back to a "conversation" intent with
an error message.

This module does NOT execute actions — it only decides WHICH action to
execute and what parameters to use. The dispatcher handles execution.

Real-time interruption:
  - route() accepts a CancellationToken. If the token is cancelled
    mid-generation (user barge-in), the router returns immediately
    with a cancelled intent and does NOT add anything to memory.
  - The caller checks result.error == "cancelled" and discards it.
"""
from __future__ import annotations

import json
import re
from typing import List, Optional

from models import LLMIntent
from services.config import LLMConfig
from services.cancellation import CancellationToken
from services.exceptions import LLMResponseError, LLMUnavailableError
from services.logger import get_logger
from utils import INTENT_CONVERSATION
from .conversation import Conversation
from .prompt import SYSTEM_PROMPT, build_router_prompt

log = get_logger("llm.router")


class LLMRouter:
    """Routes user text to a structured intent via the LLM."""

    def __init__(self, conversation: Conversation, config: LLMConfig,
                 available_intents: Optional[List[str]] = None):
        self._conversation = conversation
        self._config = config
        self._available_intents = available_intents or []

    def route(self, user_text: str,
              cancel_token: Optional[CancellationToken] = None) -> LLMIntent:
        """Route user text to a structured LLMIntent.

        This is the LLM stage of the pipeline:
            Text → LLM → Structured JSON → LLMIntent

        Args:
            user_text: The user's input (from STT).
            cancel_token: If provided and cancelled during generation,
                          returns immediately with a cancelled intent.

        Returns:
            LLMIntent with intent, parameters, response, and confidence.
            If cancelled, intent.error == "cancelled".
        """
        if not user_text or not user_text.strip():
            return LLMIntent(intent=INTENT_CONVERSATION, response="I didn't hear anything.",
                             confidence=1.0)

        # Check cancellation before starting
        if cancel_token and cancel_token.cancelled:
            return LLMIntent(intent=INTENT_CONVERSATION, response="",
                             confidence=0.0, error="cancelled")

        if not self._conversation.available:
            log.warning("LLM unavailable — returning fallback intent")
            return LLMIntent(
                intent=INTENT_CONVERSATION,
                response="I'm having trouble connecting to my reasoning engine. Please check that Ollama or your LLM backend is running.",
                confidence=0.0,
                error="LLM unavailable",
            )

        try:
            # Build the prompt with conversation history
            history = self._conversation.memory.get_history()
            prompt = build_router_prompt(user_text, history, self._available_intents)

            # Send to LLM
            log.info(f"[LLM] Routing: {user_text!r}")

            # Run the LLM call in a way that we can check for cancellation.
            # Since requests is blocking, we run it in a worker thread and
            # poll the cancel token. If cancelled, we abandon the result.
            import threading
            result_holder: dict = {"response": None, "error": None}
            thread = threading.Thread(
                target=self._call_llm, args=(user_text, result_holder),
                daemon=True, name="LLMCall"
            )
            thread.start()

            # Poll for completion or cancellation
            while thread.is_alive():
                if cancel_token and cancel_token.cancelled:
                    log.info("[LLM] Cancelled by barge-in — abandoning generation")
                    # We can't actually kill the thread, but we abandon its result.
                    # The thread will finish on its own and the result is ignored.
                    return LLMIntent(
                        intent=INTENT_CONVERSATION,
                        response="",
                        confidence=0.0,
                        error="cancelled",
                    )
                thread.join(timeout=0.1)

            # Thread completed — check for errors
            if result_holder["error"]:
                raise result_holder["error"]

            raw_response = result_holder["response"]

            # Check cancellation again before parsing
            if cancel_token and cancel_token.cancelled:
                return LLMIntent(
                    intent=INTENT_CONVERSATION,
                    response="",
                    confidence=0.0,
                    error="cancelled",
                )

            # Parse the JSON response
            intent = self._parse_response(raw_response)

            # Add assistant response to memory (only if not cancelled)
            if not (cancel_token and cancel_token.cancelled):
                self._conversation.memory.add_assistant(
                    intent.response, intent=intent.intent, action_result=None
                )

            log.info(f"[LLM] Intent: {intent.intent} (confidence={intent.confidence:.2f}"
                     f", clarification={intent.needs_clarification})")
            return intent

        except LLMUnavailableError as exc:
            log.error(f"[LLM] Unavailable: {exc}")
            return LLMIntent(
                intent=INTENT_CONVERSATION,
                response="I can't reach my reasoning engine right now.",
                confidence=0.0,
                error=str(exc),
            )
        except Exception as exc:
            log.error(f"[LLM] Router error: {exc}", exc_info=True)
            return LLMIntent(
                intent=INTENT_CONVERSATION,
                response="I'm having trouble understanding the request.",
                confidence=0.0,
                error=str(exc),
            )

    def _call_llm(self, user_text: str, result_holder: dict) -> None:
        """Worker thread that calls the LLM. Fills result_holder."""
        try:
            response = self._conversation.chat(user_text)
            result_holder["response"] = response
        except Exception as exc:
            result_holder["error"] = exc

    def _parse_response(self, raw: str) -> LLMIntent:
        """Parse the LLM's JSON response into an LLMIntent.

        Handles common LLM quirks:
          - Markdown fences (```json ... ```)
          - Extra text before/after the JSON
          - Missing fields (fills defaults)
        """
        if not raw or not raw.strip():
            raise LLMResponseError("Empty LLM response")

        # Strip markdown fences if present
        text = raw.strip()
        if "```" in text:
            m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
            if m:
                text = m.group(1)

        # Extract the JSON object
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if not m:
            log.warning(f"[LLM] No JSON found in response: {raw[:200]!r}")
            return LLMIntent(
                intent=INTENT_CONVERSATION,
                response=raw[:200],  # speak the raw response as a fallback
                confidence=0.5,
            )

        try:
            data = json.loads(m.group(0))
        except json.JSONDecodeError as exc:
            raise LLMResponseError(f"Invalid JSON: {exc}")

        return LLMIntent(
            intent=data.get("intent", INTENT_CONVERSATION),
            parameters=data.get("parameters", {}) or {},
            response=data.get("response", ""),
            confidence=float(data.get("confidence", 0.8)),
            needs_clarification=bool(data.get("needs_clarification", False)),
            clarification_options=list(data.get("clarification_options", []) or []),
        )
