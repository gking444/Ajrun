"""Conversation management — coordinates memory + LLM client + system prompt.

This module is the "conversation session" — it holds the system prompt,
the memory, and provides a single `chat()` method that the router uses.

Migrated from the working Python file's AIGateway integration.
"""
from __future__ import annotations

from typing import List

from services.config import LLMConfig, MemoryConfig
from services.exceptions import LLMUnavailableError
from services.logger import get_logger
from .client import LLMClient
from .memory import ConversationMemory
from .prompt import SYSTEM_PROMPT

log = get_logger("llm.conversation")


class Conversation:
    """A conversation session with the LLM.

    Wraps the LLMClient (migrated AIGateway) and ConversationMemory.
    The chat() method is the single entry point used by the router.
    """

    def __init__(self, llm_config: LLMConfig, memory_config: MemoryConfig):
        self._client = LLMClient(llm_config)
        self._memory = ConversationMemory(memory_config)
        self._memory.add_system(SYSTEM_PROMPT)
        self._llm_config = llm_config

    @property
    def client(self) -> LLMClient:
        return self._client

    @property
    def memory(self) -> ConversationMemory:
        return self._memory

    @property
    def available(self) -> bool:
        """True if the LLM backend is reachable."""
        return self._client.available

    def chat(self, user_text: str) -> str:
        """Send user text to the LLM and return the raw response.

        Uses the migrated AIGateway.chat_completion() method which supports
        both Ollama and OpenAI-compatible backends.

        Args:
            user_text: The user's input text.

        Returns:
            The LLM's raw text response (expected to be JSON from the router).

        Raises:
            LLMUnavailableError: If no backend is reachable.
        """
        self._memory.add_user(user_text)
        messages = self._memory.get_history()
        return self._client.chat_completion(messages, temperature=self._llm_config.temperature)
